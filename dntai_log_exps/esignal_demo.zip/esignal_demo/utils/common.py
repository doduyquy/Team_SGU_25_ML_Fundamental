__all__ = ['seed_everything']

def seed_everything (seed, tf2_set_seed = False, torch_set_seed = True):
    import random, os
    import numpy as np

    random.seed(seed)
    os.environ['PYTHONHASHSEED'] = str(seed)
    np.random.seed(seed)

    if torch_set_seed == True:
        import torch
        torch.manual_seed(seed)
        torch.cuda.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False

    if tf2_set_seed == True:
        import tensorflow as tf
        tf.random.set_seed(seed)
# seed_everything