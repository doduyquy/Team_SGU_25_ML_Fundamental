"""
# Split train/test and folds using sklearn (type = stratified / kfold)
gen_sklearn_kfold(n_fold, labels, type="stratified", randomseed=None)
"""
import numpy as np, os, pandas as pd, shutil
from sklearn.model_selection import KFold, StratifiedKFold

# Split train/test and folds using sklearn (type = stratified / kfold)
def gen_sklearn_kfold (n_fold, labels, type = "stratified", outer_shuffle = True, inner_shuffle = False, randomseed=None):
    """
    Split train/test and folds using sklearn
    Usage:
        ret = gen_sklearn_kfold(n_fold = 3, labels = np.hstack([np.ones(5) * 0, np.ones(5) * 1, np.ones(5) * 2]), type = "stratified", randomseed = None)
        for idx in ret[0].keys(): print("Fold %d: %s"%(idx, ret[0][idx]))
        print("Mask: ", ret[1])
        for idx, (train, test) in enumerate(ret[2]): print("Split %d: Train: %s - Test: %s"%(idx, train, test))
    Result:
        Fold 0: [ 6  2  4 13 14  9]
        Fold 1: [ 3  7 10  0 11  5]
        Fold 2: [ 1  8 12]
        Mask:  [1 2 0 1 0 1 0 1 2 0 1 1 2 0 0]
        Split 0: Train: [ 3  7 10  1  0  8 12 11  5] - Test: [ 6  2  4 13 14  9]
        Split 1: Train: [ 6  2  4  1 13 14  9  8 12] - Test: [ 3  7 10  0 11  5]
        Split 2: Train: [ 3  7  6  2 10  4 13  0 14  9 11  5] - Test: [ 1  8 12]
    """
    n_data = len(labels)

    np.random.seed(randomseed)
    idx_data = np.arange(n_data)
    idx_rand = np.random.permutation(idx_data) if inner_shuffle == True else idx_data

    if type == "stratified":
        gen_folds = StratifiedKFold(n_splits=n_fold, shuffle=True, random_state=randomseed)
    elif type == "kfold":
        gen_folds = KFold(n_splits=n_fold, shuffle=True, random_state=randomseed)

    idx_folds = []
    dict_fold = {}
    cnt_dict = 0
    mask_fold = np.zeros(n_data, np.int)

    for idx_train, idx_test in gen_folds.split(idx_rand, labels[idx_rand]):
        idx_folds.append([idx_rand[idx_train], idx_rand[idx_test]])
        mask_fold[idx_rand[idx_test]] = cnt_dict
        dict_fold[cnt_dict] = idx_rand[idx_test]
        cnt_dict = cnt_dict + 1
    # for

    return dict_fold, mask_fold, idx_folds
# gen_sklearn_stratified_kfold

def export_kfold(dataset_dir, kfold_dir, data_type = 'train', n_fold = 5,
                 type = "stratified", outer_shuffle = True, inner_shuffle = False, randomseed=None):
    label_path = f"{dataset_dir}/{data_type}_labels.csv"
    personality_path = f"{dataset_dir}/{data_type}_personality.csv"
    if os.path.exists(label_path) == True:
        df_data = pd.read_csv(label_path)
        labels  = df_data["label"].values
    else:
        df_data = pd.read_csv(personality_path)
        labels  = np.ones(len(df_data))

    _, _, idx_fold = gen_sklearn_kfold(n_fold, labels, outer_shuffle = True, inner_shuffle = False, randomseed = randomseed)

    # save kfold
    save_data = dict()
    for fold in range(n_fold):
        save_data_fold = dict(
            idx_train=idx_fold[fold][0],
            idx_valid=idx_fold[fold][1],
        )
        save_data_fold.update(save_data)

        if kfold_dir != "" and os.path.exists(kfold_dir) == False: os.makedirs(kfold_dir)
        path = f'{kfold_dir}/kfold{fold}.npz'
        print(f'Save fold {fold}: {path}')
        np.savez(path, **save_data_fold)
    # for
    # compress directory for backup
    print(f'Compress kfold dir: {os.path.dirname(kfold_dir)}/{os.path.basename(kfold_dir)}_lastest.zip')
    shutil.make_archive(f"{os.path.dirname(kfold_dir)}/{os.path.basename(kfold_dir)}_lastest", 'zip', kfold_dir)