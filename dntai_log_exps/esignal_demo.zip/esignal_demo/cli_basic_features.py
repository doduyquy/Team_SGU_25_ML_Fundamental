import os, sys
import random

# script info
script_dir  = os.path.normpath(os.path.dirname(os.path.abspath(__file__))) # path to train.py
root_dir    = os.path.normpath(os.path.abspath(script_dir + "/.."))
source_dir  = root_dir

if source_dir in sys.path: sys.path.remove(source_dir)
sys.path.insert(1, source_dir)

from esignal.common import *
from esignal.utils import *
from esignal.datasets.kerc21_data import *

script_date = datetime.now()
script_sdate = f'{script_date:%y%m%d_%H%M%S}_{random.randint(0, 100):02}'

# skip warning
warnings.filterwarnings("ignore")

def options_common(func):
    """
    https://stackoverflow.com/questions/5409450/can-i-combine-two-decorators-into-a-single-one-in-python
    """
    options  = [
        click.option("--logs-file", type=str, default="{root_dir}/logs/logs.txt"),
        click.option("--app-cfg", type=str, default=""),
        click.option("--evalf", type=str, multiple=True, default=['dataset_dir','logs_file']),
        click.option("--add-evalf", type=str, multiple=True, default=[]),
        click.option("--debug", type=int, default=0)
    ]
    for option in options: func = option(func)
    return func

def process_options(ctx, **params):
    # init params
    ctx.obj["params"].update(**params)
    params = ctx.obj["params"]

    for k in ['script_dir', 'script_date', 'script_sdate', 'root_dir', 'source_dir']:
        if params.get(k) is None: params[k] = globals()[k]

    params['evalf'] = list(params['evalf'])
    params['evalf'].extend(list(params['add_evalf']))
    params['evalf'].append('logs_file')
    for k in params['evalf']:
        if params.get(k) is not None:
            params[k] = eval("f'%s'" % (params[k]), {**globals(), **locals(), **params})

    logs_dir = os.path.dirname(params["logs_file"])
    if logs_dir != "" and os.path.exists(logs_dir) == False: os.makedirs(logs_dir)
    tee_log.append(f'{params["logs_file"]}')
    print(f'[Program Start]\n+ Script Date: {script_sdate}')
    print(f'\n[Command {ctx.command.name}]')

    print('params: ')
    for k in params: print(f'+ {k}: {pformat(params[k])}')

    if params["debug"] == 1: raise Exception(f'Exit Debug Options')

    globals().update(**locals())
    return params

@click.group(invoke_without_command=True)
@click.pass_context
def main(ctx, **params):
    ctx.ensure_object(dict)

@main.command(context_settings=dict(ignore_unknown_options=True, allow_extra_args = True), name = 'baseline')
@click.option("--dataset-dir", type=str, default="{root_dir}/data/KERC21Dataset")
@click.option("--export-dir", type=str, default="{root_dir}/data/KERC21Dataset/preprocessed/baseline")
@click.option("--db-names", type=str, multiple=True, default=['train', 'val', 'test'])
@click.option("--eeg-sampling-freq", type=int, default=256)
@click.option("--eda-sr", type=int, default=4)
@click.option("--bvp-sr", type=int, default=64)
@options_common
@click.option("--add-evalf", type=str, multiple=True, default=['export_dir'])
@click.pass_context
def main_baseline(ctx, **params):
    params = process_options(ctx, **params)

    data_cls = KERC21Data(params["dataset_dir"])
    if params["debug"] == 0:
        build_feat_baseline(data_cls, export_dir=params["export_dir"],
                            eeg_sampling_freq = params["eeg_sampling_freq"],
                            eda_sr = params["eda_sr"],
                            bvp_sr = params["bvp_sr"])
    globals().update(**locals())
    pass
# main_baseline

@main.command(context_settings=dict(ignore_unknown_options=True, allow_extra_args = True), name = 'baseline-scales')
@click.option("--dataset-dir", type=str, default="{root_dir}/data/KERC21Dataset")
@click.option("--export-dir", type=str, default="{root_dir}/data/KERC21Dataset/preprocessed/baseline_scales")
@click.option("--db-names", type=str, multiple=True, default=['train', 'val', 'test'])
@click.option("--eeg-sampling-freq", type=int, default=256)
@click.option("--eeg-scales", type=int, multiple=True, default=[8, 4, 2, 1])
@click.option("--eda-sr", type=int, default=4)
@click.option("--eda-scales", type=int, multiple=True, default=[8, 4, 2, 1])
@click.option("--bvp-sr", type=int, default=64)
@click.option("--bvp-scales", type=int, multiple=True, default=[2, 1])
@click.option("--pooling", type=str, default="concat")
@options_common
@click.option("--add-evalf", type=str, multiple=True, default=['export_dir'])
@click.pass_context
def main_baseline_scales(ctx, **params):
    params = process_options(ctx, **params)

    data_cls = KERC21Data(params["dataset_dir"])

    if params["debug"] == 0:
        build_feat_baseline_scales(data_cls, export_dir=params["export_dir"],
                                   eeg_sampling_freq = params["eeg_sampling_freq"], eeg_scales = params["eeg_scales"],
                                   eda_sr = params["eda_sr"], eda_scales = params["eda_scales"],
                                   bvp_sr = params["bvp_sr"], bvp_scales = params["bvp_scales"],
                                   pooling = params["pooling"])
    globals().update(**locals())
    pass
# main_baseline_scales

@main.command(context_settings=dict(ignore_unknown_options=True, allow_extra_args = True), name = 'baseline-temp-scales')
@click.option("--dataset-dir", type=str, default="{root_dir}/data/KERC21Dataset")
@click.option("--export-dir", type=str, default="{root_dir}/data/KERC21Dataset/preprocessed/baseline_scales")
@click.option("--db-names", type=str, multiple=True, default=['train', 'val', 'test'])
@click.option("--eeg-sampling-freq", type=int, default=256)
@click.option("--eeg-scales", type=int, multiple=True, default=[8, 4, 2, 1])
@click.option("--eda-sr", type=int, default=4)
@click.option("--eda-scales", type=int, multiple=True, default=[8, 4, 2, 1])
@click.option("--bvp-sr", type=int, default=64)
@click.option("--bvp-scales", type=int, multiple=True, default=[2, 1])
@click.option("--temp-sr", type=int, default=4)
@click.option("--temp-scales", type=int, multiple=True, default=[2, 1])
@click.option("--personality-onehot", type=int, default=0)
@click.option("--personality-scales", type=int, multiple=True, default=[1])
@click.option("--pooling", type=str, default="concat")
@options_common
@click.option("--add-evalf", type=str, multiple=True, default=['export_dir'])
@click.pass_context
def main_baseline_temp_scales(ctx, **params):
    params = process_options(ctx, **params)

    data_cls = KERC21Data(params["dataset_dir"])

    if params["debug"] == 0:
        build_feat_temp_baseline_scales(data_cls, export_dir=params["export_dir"],
                                        eeg_sampling_freq = params["eeg_sampling_freq"], eeg_scales = params["eeg_scales"],
                                        eda_sr = params["eda_sr"], eda_scales = params["eda_scales"],
                                        bvp_sr = params["bvp_sr"], bvp_scales = params["bvp_scales"],
                                        temp_sr = params["temp_sr"], temp_scales = params["temp_scales"],
                                        pooling = params["pooling"])
    globals().update(**locals())
    pass
# main_baseline_temp_scales

@main.command(context_settings=dict(ignore_unknown_options=True, allow_extra_args = True), name = 'baseline-deep-scales')
@click.option("--dataset-dir", type=str, default="{root_dir}/data/KERC21Dataset")
@click.option("--deep-feat-dirs", type=str, multiple = True, default=[])
@click.option("--deep-feat-cfgs", type=str, multiple = True, default=[])
@click.option("--export-dir", type=str, default="{root_dir}/data/KERC21Dataset/preprocessed/baseline_deep")
@click.option("--db-names", type=str, multiple=True, default=['train', 'val', 'test'])
@click.option("--db-types", type=str, multiple=True, default=['train', 'val', 'test'])
@click.option("--eeg-sampling-freq", type=int, default=256)
@click.option("--eeg-scales", type=int, multiple=True, default=[8, 4, 2, 1]) 
@click.option("--eeg-fn-name", type=str, default="get_eeg_features_trans") # get_eeg_features_extra_trans, # get_eeg_features_trans
@click.option("--eda-sr", type=int, default=4)
@click.option("--eda-scales", type=int, multiple=True, default=[8, 4, 2, 1])
@click.option("--bvp-sr", type=int, default=64)
@click.option("--bvp-scales", type=int, multiple=True, default=[2, 1])
@click.option("--temp-sr", type=int, default=4)
@click.option("--temp-scales", type=int, multiple=True, default=[2, 1])
@click.option("--personality-onehot", type=int, default=0)
@click.option("--pooling", type=str, default="concat")
@click.option("--logs-file", type=str, default="{export_dir}/logs.txt")
@options_common
@click.option("--add-evalf", type=str, multiple=True, default=['export_dir', 'logs_file'])
@click.pass_context
def main_baseline_deep_scales(ctx, **params):
    params = process_options(ctx, **params)

    extra_feat_dirs = list(params["deep_feat_dirs"])
    for idx in range(len(extra_feat_dirs)):
        extra_feat_dirs[idx] = eval("f'%s'" % (extra_feat_dirs[idx]), {**globals(), **locals(), **params})
    
    extra_feat_cfgs = list(params["deep_feat_cfgs"])
    for idx in range(len(extra_feat_cfgs)):
        extra_feat_cfgs[idx] = [si.strip() for si in extra_feat_cfgs[idx].split(",")]
    

    data_cls = KERC21Data(params["dataset_dir"], 
            data_names = params["db_names"],
            data_types = params["db_types"],
            extra_feat_dirs = extra_feat_dirs, 
            extra_feat_cfgs = extra_feat_cfgs)

    feat_cfgs = DEFAULT_FEATURE_CFGS
    feat_cfgs["eeg"]["multiscales"]  = list(params[f"eeg_scales"])
    feat_cfgs["bvp"]["multiscales"]  = list(params[f"bvp_scales"])
    feat_cfgs["eda"]["multiscales"]  = list(params[f"eda_scales"])
    feat_cfgs["temp"]["multiscales"] = list(params[f"temp_scales"])

    feat_cfgs["eeg"]["fn_name"]  = params[f"eeg_fn_name"]
    feat_cfgs["eeg"]["fn_params"]  = [params[f"eeg_sampling_freq"]]

    feat_cfgs["bvp"]["fn_params"]  = [params[f"bvp_sr"]]
    feat_cfgs["eda"]["fn_params"]  = [params[f"eda_sr"]]
    feat_cfgs["temp"]["fn_params"] = [params[f"temp_sr"]]

    feat_cfgs["eeg"]["pooling"]  = params["pooling"]
    feat_cfgs["bvp"]["pooling"]  = params["pooling"]
    feat_cfgs["eda"]["pooling"]  = params["pooling"]
    feat_cfgs["temp"]["pooling"] = params["pooling"]

    feat_infos = ["eeg", "bvp", "eda", "temp"]
    for extra_feat_cfg in extra_feat_cfgs:
        feature_names = [os.path.splitext(file)[0] for file in extra_feat_cfg[1:]]
        for feature_name in feature_names:
            feat_infos.append((f'{extra_feat_cfg[0]}_{feature_name}', "default"))

    if params["debug"] == 0:
        build_feat_extra_baseline_scales(data_cls, export_dir=params["export_dir"], 
                    feat_infos = feat_infos, feat_cfgs = feat_cfgs, global_scope=globals())
    
    globals().update(**locals())
    pass
# main_baseline_deep_scales

@main.command(context_settings=dict(ignore_unknown_options=True, allow_extra_args = True), name = 'eda-stat-features')
@click.option("--dataset-dir", type=str, default="{root_dir}/data/KERC21Dataset")
@click.option("--data-names", type=str, multiple=True, default=["train"])
@click.option("--stat-features", type=str, multiple=True, default=["eeg", "eda", "temp", "bvp", "personality"])
@click.option("--stat-types", type=int, multiple=True, default=[-2, -1, -1, -1, -2])
@click.option("--stat-names", type=str, multiple=True, default=["mean", "std"])
@click.option("--export-dir", type=str, default="{root_dir}/data/KERC21Dataset/preprocessed")
@click.option("--export-name", type=str, default="stat_features_lastest.npz")
@options_common
@click.option("--logs-file", type=str, default="{root_dir}/logs/logs_eda_stat_features.txt")
@click.option("--add-evalf", type=str, multiple=True, default=['export_dir'])
@click.pass_context
def main_eda_stat_features(ctx, **params):
    params = process_options(ctx, **params)
    data_cls = KERC21Data(params["dataset_dir"])
    stat_info, df_stat_info = eda_stat_features(data_cls, **{k:params[k] for k in ["data_names", "stat_features", "stat_types", "stat_names", "export_dir", "export_name"]})
    globals().update(**locals())
    pass
# main_eda_stat_features

@main.command(context_settings=dict(ignore_unknown_options=True, allow_extra_args = True), name = 'test')
@click.option("--dataset-dir", type=str, default="{root_dir}/data/KERC21Dataset")
@options_common
@click.pass_context
def main_test(ctx, **params):
    params = process_options(ctx, **params)
    data_cls = KERC21Data(params["dataset_dir"])
    globals().update(**locals())
    pass
# main_test

if __name__ == "__main__":
    ctx_obj = {"tee_log": None, "params": {}}
    try:
        with TeeLog() as tee_log:
            ctx_obj["tee_log"] = tee_log
            main(obj=ctx_obj)
    except SystemExit as ex:
        with TeeLog(ctx_obj["params"]["logs_file"], "at") as tee_log:
            print(f'\n[Program Exit]\n+ Exit Code: {ex}')