import numpy as np

from .features import *

__all__ = ["build_multiscales", "get_eeg_features_scales", "get_eda_features_scales",
           "get_bvp_features_scales", "get_temp_features_scales"]

def build_multiscales(feat_data, fn_data, multiscales = [4, 2, 1], pooling = None):
    """
    :param feat_data:
    :param fn_data:
    :param multiscales:
    :param pooling: None, "concat" (concat), "scales" (list), "max", "mean", "avg"
    :return:
    """
    n_data    = len(feat_data)
    steps     = [(n_data + scale - 1) // scale for scale in multiscales]
    step_pads = [scale * step - min(scale * step, n_data) for step, scale in zip(steps,multiscales)]
    max_pad = np.max(step_pads)
    feat_data_pad = np.pad(feat_data, (0, max_pad))

    feat_all_scales = []
    for step, scale in zip(steps, multiscales):
        range_scales  = [range(chunk * step, (chunk + 1) * step) for chunk in range(scale)]
        feat_scales = []
        for range_scale in range_scales:
            feat_scale = fn_data(feat_data_pad[list(range_scale)])
            feat_all_scales.append(feat_scale)
    # for
    if pooling is None or pooling == "concat":
        feat_all_scales = np.concatenate(feat_all_scales)
    elif pooling == "max":
        feat_all_scales = np.max(feat_all_scales, axis = 0)
    elif pooling == "min":
        feat_all_scales = np.min(feat_all_scales, axis = 0)
    elif pooling == "avg":
        feat_all_scales = np.average(feat_all_scales, axis = 0)
    elif pooling == "scales":
        pass
    return feat_all_scales
# build_multiscales

def get_eeg_features_scales(egg_data, sampling_freq, multiscales = [8, 4, 2, 1], pooling = "concat", **kwargs):
    fn_data   = lambda data: get_eeg_features(data.T, sampling_freq)
    feat_data = build_multiscales(egg_data, fn_data, multiscales, pooling)
    return feat_data
# get_eeg_features_scales

def get_eda_features_scales(eda_data, sr, multiscales = [8, 4, 2, 1], pooling = "concat"):
    fn_data   = lambda data: get_gsr_features(data, sr)
    feat_data = build_multiscales(eda_data, fn_data, multiscales, pooling)
    return feat_data
# get_eda_features_scales

def get_bvp_features_scales(bvp_data, sr, multiscales = [2, 1], pooling = "concat"):
    fn_data   = lambda data: get_bvp_features(data, sr)
    feat_data = build_multiscales(bvp_data, fn_data, multiscales, pooling)
    return feat_data
# get_bvp_features_scales

def get_temp_features_scales(temp_data, sr, multiscales = [2, 1], pooling = "concat"):
    fn_data   = lambda data: get_hst_features(data, sr)
    feat_data = build_multiscales(temp_data, fn_data, multiscales, pooling)
    return feat_data
# get_temp_features_scales