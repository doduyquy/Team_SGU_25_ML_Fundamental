"""
Source from KERC21 Challenge
"""
import os
import sys, getopt
import numpy as np
import pandas as pd
import math
from scipy import signal
from tqdm import tqdm
from pyteap.signals.gsr import get_gsr_features
from pyteap.signals.bvp import get_bvp_features
from pyteap.signals.hst import get_hst_features
from mne_features.univariate import compute_mean, compute_pow_freq_bands, compute_wavelet_coef_energy
from mne_features.univariate import compute_std, compute_spect_entropy, compute_katz_fd, compute_kurtosis, \
                                    compute_hjorth_complexity, compute_ptp_amp

from mne_features.univariate import compute_skewness, compute_hurst_exp
from mne_features.univariate import compute_app_entropy
from mne_features.univariate import compute_spect_edge_freq, compute_energy_freq_bands
from mne_features.univariate import compute_teager_kaiser_energy, compute_wavelet_coef_energy

import warnings
warnings.filterwarnings("ignore")

__all__ = ["get_bvp_features", "get_gsr_features", "get_psd_features", "get_psd_ftrs", "get_eeg_features", \
           "get_one_hot", "get_hst_features", "get_eeg_features_trans", 
           "get_eeg_features_extra", "get_eeg_features_extra_trans"]

def bandpass_filter (data, low, high, sampling_rate):
    nyq = 0.5 * sampling_rate
    low = low / nyq
    high = high / nyq
    order = 2
    b, a = signal.butter(order, [low, high], btype='band')
    filtered = signal.lfilter(b, a, data)
    return filtered
# bandpass_filter

def get_psd_features (eeg_data, sampling_freq):
    ftrs = []
    for channel_data in eeg_data:
        channel_psd_ftrs = []
        for _, (lo, hi) in {'theta': (3, 7), 'alpha': (8, 13), 'beta': (14, 29), 'gamma': (30, 47)}.items():
            band_signal = bandpass_filter(channel_data, lo, hi, sampling_freq)
            window_size = 10  # Using 10s window with 50% overlap
            _, psd = signal.welch(band_signal, sampling_freq, nperseg=sampling_freq * window_size,
                                  noverlap=sampling_freq * window_size / 2)
            # ftr = math.log(np.max(psd))
            channel_psd_ftrs.append(psd)
        ch_ftrs = np.array(channel_psd_ftrs).ravel()  # concatenate psd of 4 bands (theta alpha beta gamma)
        ftrs.append(ch_ftrs)

    psd_ftrs = np.array(
        ftrs).ravel()  # concatentate freatures from 14 channels (CH1(theta alpha beta gamma) - CH14(theta alpha beta gamma))
    return psd_ftrs
# get_psd_features

def get_psd_ftrs (eeg_data, sampling_freq):
    ftrs = []
    for channel_data in eeg_data:
        for _, (lo, hi) in {'theta': (3, 7), 'alpha': (8, 13), 'beta': (14, 29), 'gamma': (30, 47)}.items():
            band_signal = bandpass_filter(channel_data, lo, hi, sampling_freq)
            window_size = 10  # Using 10s window with 50% overlap
            _, psd = signal.welch(band_signal, sampling_freq, nperseg=sampling_freq * window_size,
                                  noverlap=sampling_freq * window_size / 2)
            ftr = math.log(np.max(psd))
            ftrs.append(ftr)
    return np.array(ftrs)
# get_psd_ftrs

def get_eeg_features (eeg_data, sampling_freq):
    mean = compute_mean(eeg_data)  # 14
    std = compute_std(eeg_data)  # 14
    power_freq = compute_pow_freq_bands(sampling_freq, eeg_data, [4, 8, 13, 30, 40])  # 56
    wavelet_coef_energy = compute_wavelet_coef_energy(eeg_data)  # 84
    spectral_entropy = compute_spect_entropy(sampling_freq, eeg_data)  # 14
    kurtosis = compute_kurtosis(eeg_data)  # 14
    hjorth_complexity = compute_hjorth_complexity(eeg_data)  # 14
    p2p = compute_ptp_amp(eeg_data)  # 14
    fd = compute_katz_fd(eeg_data)  # 14
    psd = get_psd_ftrs(eeg_data, sampling_freq)  # 56
    return np.hstack(
        (mean, std, power_freq, wavelet_coef_energy, spectral_entropy, kurtosis, hjorth_complexity, p2p, fd, psd)
    )
# get_eeg_features

def get_eeg_features_trans(eeg_data, sampling_freq):
    return get_eeg_features(eeg_data.T, sampling_freq)

def get_one_hot(feat, clas):
    one_hot = np.zeros((len(feat), clas), dtype=np.int)
    for idx, val in enumerate(feat): one_hot[idx, val] = 1
    return one_hot
# get_one_hot

"""
mean, std, ptp_amp, kurtosis, hjorth, spectral_entropy

power_freq, wavelet, psd, katz


Time:
    compute_skewness, hurst_exp

Freq:    
    spect_edge_freq

Time-Freq:
    teager_kaiser_energy

"""
def get_eeg_features_extra (eeg_data, sampling_freq):
    
    # time Domain
    mean = compute_mean(eeg_data)  # 14 OK
    std = compute_std(eeg_data)  # 14 OK
    p2p = compute_ptp_amp(eeg_data)  # 14 OK
    kurtosis = compute_kurtosis(eeg_data)  # 14 OK
    hjorth_complexity = compute_hjorth_complexity(eeg_data)  # 14 OK
    spectral_entropy = compute_spect_entropy(sampling_freq, eeg_data)  # 14 OK
    fd = compute_katz_fd(eeg_data)  # 14
    
    skewness = compute_skewness(eeg_data)  # 14 NEW
    # hurst_exp = compute_hurst_exp(eeg_data) # 14 NEW
    
    # frequency domain
    # power_freq = compute_pow_freq_bands(sampling_freq, eeg_data, [4, 8, 13, 30, 40])  # 56 OK
    power_freq = compute_pow_freq_bands(sampling_freq, eeg_data, [0.5, 4, 8, 13, 30, 40, 100])  # 84 [MOD]
    psd = get_psd_ftrs(eeg_data, sampling_freq)  # 56 OK

    energy_freq_bands = compute_energy_freq_bands(sampling_freq, eeg_data, [0.5, 4, 8, 13, 30, 40, 100]) # 84 NEW
    spect_edge_freq = compute_spect_edge_freq(sampling_freq, eeg_data) # 14 NEW

    # time-frequency domain
    wavelet_coef_energy = compute_wavelet_coef_energy(eeg_data)  # 84 OK
    teager_kaiser_energy = compute_teager_kaiser_energy(eeg_data) # 196 NEW

    return np.hstack(
        (mean, std, power_freq, wavelet_coef_energy, spectral_entropy, kurtosis, hjorth_complexity, p2p, fd, psd, \
        skewness, \
        energy_freq_bands, spect_edge_freq, \
        teager_kaiser_energy, \
        )
    )
# get_eeg_features_extra

def get_eeg_features_extra_trans(eeg_data, sampling_freq):
    return get_eeg_features_extra(eeg_data.T, sampling_freq)