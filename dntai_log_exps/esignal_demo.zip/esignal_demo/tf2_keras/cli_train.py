import os, sys
import joblib
import random
import pprint
import pickle

# script info
script_dir  = os.path.normpath(os.path.dirname(os.path.abspath(__file__))) # path to train.py
root_dir    = os.path.normpath(os.path.abspath(script_dir + "/../.."))
source_dir  = root_dir

if source_dir in sys.path: sys.path.remove(source_dir)
sys.path.insert(1, source_dir)

import esignal.tf2_keras.data.kerc21_dataset
import importlib
importlib.reload(esignal.tf2_keras.data.kerc21_dataset)

from esignal.common import *
from esignal.utils import *
from esignal.datasets.kerc21_data import *
from esignal.tf2_keras.common import *

from esignal.tf2_keras.data.kerc21_dataset import KERC21Dataset

script_date  = datetime.now()
script_sdate = f'{script_date:%y%m%d_%H%M%S}_{random.randint(0, 100):02}'

data_dir    = os.path.normpath(os.path.abspath(f'{root_dir}/data'))
exps_dir    = os.path.normpath(os.path.abspath(f'{root_dir}/logs'))

# skip warning
warnings.filterwarnings("ignore")
pprint
def generate_kfolds(ds, data_filter, k_fold, n_repeats, seed):
    kfold = RepeatedStratifiedKFold(n_splits=params["k_fold"], n_repeats=params["n_repeats"], random_state=params["seed"])
    kfold_info = {}

    data_filter_cfg = dict(np.load(params["data_filter"]))
    train_index = data_filter_cfg["idx_train"]
    y_train     = ds.lbl_all_ids[train_index]
    ids_train   = ds.all_ids[train_index]

    test_index = data_filter_cfg["idx_valid"]
    y_test     = ds.lbl_all_ids[test_index]
    ids_test   = ds.all_ids[test_index]

    for name in ["train_index", "y_train", "ids_train", "test_index", "y_test", "ids_test"]:
        kfold_info[name] = locals()[name]

    kfold_info["n_folds"] = 0
    for fold, (train_idx, test_idx) in enumerate(kfold.split(train_index, y_train)):
        trainvalid_index, y_trainvalid, ids_trainvalid =  train_index[train_idx], y_train[train_idx], ids_train[train_idx]
        valid_index     , y_valid, ids_valids          =  train_index[test_idx], y_train[test_idx], ids_train[test_idx]

        kfold_info[f'fold_{fold}'] = {}
        for name in ["trainvalid_index", "y_trainvalid", "ids_trainvalid", "valid_index", "y_valid", "ids_valids"]:
            kfold_info[f'fold_{fold}'][name] = locals()[name]
        kfold_info["n_folds"] = kfold_info["n_folds"] + 1
    # for
    return kfold_info
# generate_kfolds

def train(ctx, **params):
    print("-" * 50)
    print("TRAIN")
    print("-" * 50)

    # make exps_dir
    exps_dir = params["exps_dir"]
    if exps_dir != "" and os.path.exists(exps_dir) == False: os.makedirs(exps_dir)
    print(f'+ Make exps_dir: {exps_dir}')

    # set seed
    print(f'+ Set seed everythings: {params["seed"]}')
    seed_everything(params["seed"])

    # data class
    print(f'+ Load data class at {params["dataset_dir"]}')
    data_cls = KERC21Data(params["dataset_dir"])

    # dataset
    train_dataset  = KERC21Dataset(data_cls,
                                   data_names=["train"],
                                   data_filter = {"train": None},
                                   data_features={"x": ["eeg", "eda", "bvp", "temp", "personality"],
                                                  "y": ["label_id_onehot"]},
                                   verbose = 0, )
    valid_dataset  = KERC21Dataset(data_cls,
                                   data_names=["train"],
                                   data_filter = {"train": None},
                                   data_features={"x": ["eeg", "eda", "bvp", "temp", "personality"],
                                                  "y": ["label_id_onehot"]},
                                   verbose = 0, )
    test_dataset  = KERC21Dataset(data_cls,
                                   data_names=["train"],
                                   data_filter = {"train": None},
                                   data_features={"x": ["eeg", "eda", "bvp", "temp", "personality"],
                                                  "y": ["label_id_onehot"]},
                                   verbose = 0, )

    # load kfold
    print("-" * 20)
    kfold_path = f'{exps_dir}/kfold_info.joblib'
    force_generate = False
    if force_generate == True or os.path.exists(kfold_path) == False:
        print(f"+ Generate kfold info: {kfold_path}")
        kfold_info = generate_kfolds(train_dataset, **{k: params[k] for k in ["data_filter", "k_fold", "n_repeats", "seed"]})
        joblib.dump(kfold_info, kfold_path)
        with open(kfold_path + ".txt", "wt") as file:
            file.write(pprint.pformat(kfold_info))
    else:
        print(f"+ Load kfold info: {kfold_path}")
        kfold_info = joblib.load(kfold_path)


    n_folds = kfold_info["n_folds"]

    print(f'+ Train Size: {len(kfold_info["train_index"])}')
    print(f'+ Test  Size: {len(kfold_info["test_index"])}')
    print(f'+ Number of k-folds: {n_folds}')

    print("-" * 20)
    test_dataset.set_filter_index(kfold_info["test_index"])
    for fold in range(n_folds):
        fold_cfg = kfold_info[f'fold_{fold}']
        train_dataset.set_filter_index(fold_cfg["trainvalid_index"])
        valid_dataset.set_filter_index(fold_cfg["valid_index"])


        print(f'FOLD {fold}')
        print("-" * 20)
        print(f'+ TrainValid Size: {len(train_dataset)}')
        print(f'+ Valid Size: {len(valid_dataset)}')

        train_loader = train_dataset.to_dataset(data_type="train")
        valid_loader = valid_dataset.to_dataset(data_type="valid")
        test_loader  = test_dataset.to_dataset(data_type="valid")


        print()

    process_end(**locals())

def options_common(func):
    """
    https://stackoverflow.com/questions/5409450/can-i-combine-two-decorators-into-a-single-one-in-python
    """
    options  = [
        click.option("--logs-file", type=str, default="{root_dir}/logs/logs.txt"),
        click.option("--app-cfg", type=str, default=""),
        click.option("--evalf", type=str, multiple=True, default=['logs_file']),
        click.option("--add-evalf", type=str, multiple=True, default=[]),
        click.option("--seed", type=int, default=1),
        click.option("--debug", type=int, default=0)
    ]
    for option in options: func = option(func)
    return func

def process_options(ctx, params):
    # init params
    ctx.obj["params"].update(**params)
    params = ctx.obj["params"]

    for k in ['script_dir', 'script_date', 'script_sdate', 'root_dir', 'source_dir', 'data_dir', 'exps_dir']:
        if params.get(k) is None: params[k] = globals()[k]

    params['evalf'] = list(params['evalf'])
    params['evalf'].extend(list(params['add_evalf']))
    for k in params['evalf']:
        if params.get(k) is not None:
            params[k] = eval("f'%s'" % (params[k]), {**globals(), **locals(), **params})

    logs_dir = os.path.dirname(params["logs_file"])
    if logs_dir != "" and os.path.exists(logs_dir) == False: os.makedirs(logs_dir)
    tee_log.append(f'{params["logs_file"]}')
    print("-" * 50)
    print(f'[Command {ctx.command.name}] - {script_sdate}')
    print("-" * 50)

    print('params: ')
    for k in params: print(f'+ {k}: {pformat(params[k])}')

    if params["debug"] == 1: raise Exception(f'Exit Debug Options')

    globals().update(**locals())
    return params

def process_end(ctx, **params):
    globals().update(**params)

@click.group(invoke_without_command=True)
@click.pass_context
def main(ctx, **params):
    ctx.ensure_object(dict)
# main

@main.command(context_settings=dict(ignore_unknown_options=True, allow_extra_args = True), name = 'train')
@click.option("--dataset-dir", type=str, default="{root_dir}/data/KERC21Dataset")
@click.option("--data-filter", type=str, default="{root_dir}/data/KERC21Dataset/preprocessed/kfold1/kfold1.npz")
@click.option("--exps-name", type=str, default="baseline")
@click.option("--desc-name", type=str, default="test")
@click.option("--exps-dir", type=str, default="{root_dir}/logs/tf2_keras/test/{exps_name}_{desc_name}")
@click.option("--k-fold", type=int, default=5)  # data_filter --> train / valid
@click.option("--n-repeats", type=int, default=2)
@options_common
@click.option("--add-evalf", type=str, multiple=True, default=["dataset_dir", "data_filter", "exps_dir"])
@click.pass_context
def main_train(ctx, **params):
    params = process_options(ctx, params)
    train(ctx, **params)
    process_end(**locals())
# main_train

@main.command(context_settings=dict(ignore_unknown_options=True, allow_extra_args = True), name = 'test')
@click.option("--dataset-dir", type=str, default="{root_dir}/data/KERC21Dataset")
@options_common
@click.option("--add-evalf", type=str, multiple=True, default=["dataset_dir"])
@click.pass_context
def main_test(ctx, **params):
    params = process_options(ctx, params)
    train(ctx, **params)
    process_end(**locals())
# main_test

if __name__ == "__main__":
    ctx_obj = {"tee_log": None, "params": {}, 'global_scope': globals()}
    try:
        with TeeLog() as tee_log:
            ctx_obj["tee_log"] = tee_log
            main(obj=ctx_obj)
    except SystemExit as ex:
        with TeeLog(ctx_obj["params"]["logs_file"], "at") as tee_log:
            print(f'\n[Program Exit]\n+ Exit Code: {ex}')