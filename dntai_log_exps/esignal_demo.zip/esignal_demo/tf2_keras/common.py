# tf2 keras
import tensorflow as tf
from tensorflow import keras
import tensorflow_addons as tfa
import tensorflow_io as tfio

from tensorflow.keras.layers import Input
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Conv1D
