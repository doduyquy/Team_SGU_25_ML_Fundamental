import tensorflow as tf
from tensorflow.keras.layers import Input, Embedding
from tensorflow.keras.models import Model, Sequential
from tensorflow.keras.layers import Conv1D, MaxPool1D, Activation, BatchNormalization, Flatten
from tensorflow.keras.layers import GlobalAveragePooling1D, GlobalMaxPooling1D

from esignal.tf2_keras.common import *

from esignal.tf2_keras.models.utils import conv1d_temporal_block

def classification_blocks(x,
                          class_name = "signal_emotion_class",
                          nb_classes = 4,
                          fc_finals = [352, 512],
                          fc_dropout = [0.1, 0.1, 0.1]):
    if fc_dropout[0]>0: x = Dropout(fc_dropout[0], name = "dropout_1")(x)
    if fc_finals[0]>0:  x = Dense(fc_finals[0], activation='relu', name=f'{class_name}_feature1')(x)
    if fc_dropout[1]>0: x = Dropout(fc_dropout[1], name = "dropout_2")(x)
    if fc_finals[1]>0:  x = Dense(fc_finals[1], activation='relu', name=f'{class_name}_feature2')(x)
    if fc_dropout[2]>0: x = Dropout(fc_dropout[2], name = "dropout_3")(x)
    x = Dense(nb_classes, activation='softmax', name=f'{class_name}_predictions_class')(x)
    return x
# def classification_blocks

def MultiTaskStatSignalModel(eeg_shape  = (15360, 14),
                             eda_shape  = (241,  1),
                             bvp_shape  = (3841, 1),
                             temp_shape = (241,  1),
                             # 5 personality --> 4 scores ==> [[0, 1, 0, 2, 3], [0, 1, 0, 2, 3], ...]
                             # input_dim = voca_size = 4, input_length = 5, output_dim
                             pers_embedding = (4,  4, 5), # input_dim = voca_size, output_dim, input_length
                             model_name = "model",
                             **kwargs):
    inputs  = []
    outputs = []
    x_all   = []

    # eeg
    eeg_input = Input(shape=eeg_shape, name = "input_eeg")
    inputs.append(eeg_input)
    x1, _ = conv1d_temporal_block(eeg_input, class_name = "eeg_convtemp1")
    outputs.append(x1)

    # eda
    # eda_input = Input(shape=eda_shape, name = "input_eda")
    # inputs.append(eda_input)
    # x2, _ = conv1d_temporal_block(eda_input, class_name = "eda_convtemp1", attention_module = '')
    # outputs.append(x2)

    # bvp
    # bvp_input = Input(shape=bvp_shape, name="input_bvp")
    # inputs.append(bvp_input)
    # x3, _ = conv1d_temporal_block(bvp_input, class_name = "bvp_convtemp1", attention_module = '')
    # outputs.append(x3)
        
    
    # # temp
    # temp_input = Input(shape=temp_shape, name="input_temp")
    # inputs.append(temp_input)
    # x4, _ = conv1d_temporal_block(temp_input, class_name = "temp_convtemp1", attention_module = '')
    # outputs.append(x4)    


    # # personality
    # pers_input = Input(shape=(pers_embedding[2],), name="input_pers")
    # inputs.append(pers_input)  
    # pers_embedding = Embedding(input_dim=pers_embedding[0], output_dim=pers_embedding[1], input_length=pers_embedding[2], name="pers_input")(pers_input)
    # x5 = pers_embedding
    # x5 = Flatten()(x5)
    # outputs.append(x5)


    # Outputs
    print("Model: ")
    print(f"+ Inputs: {inputs}")
    for xi in inputs: print(f'  * {xi}')
    print(f"+ Outputs: {outputs}")
    for xi in outputs: print(f'  * {xi}')

    model = Model(inputs = inputs, outputs = outputs, name = 'MultiTaskStatSignalModel')

    model.summary()
    globals().update(**locals())
    pass

def test1(**kwargs):
    MultiTaskStatSignalModel()
    globals().update(**locals())
    pass

if __name__ == "__main__":
    test1()
    pass