"""
https://gist.github.com/cbaziotis/6428df359af27d58078ca5ed9792bd6d
"""

