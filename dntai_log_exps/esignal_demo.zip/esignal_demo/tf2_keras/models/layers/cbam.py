"""
https://github.com/kobiso/CBAM-keras
https://github.com/kobiso/CBAM-keras/blob/master/models/attention_module.py

Contains the implementation of Convolutional Block Attention Module(CBAM) block.
As described in https://arxiv.org/abs/1807.06521.
"""
import tensorflow as tf
from tensorflow.keras.layers import GlobalAveragePooling2D, GlobalMaxPooling2D, Reshape, Dense, multiply, Permute, Concatenate, \
                                    Conv2D, Add, Activation, Lambda
from tensorflow.keras.layers import GlobalAveragePooling1D, GlobalMaxPooling1D, Conv1D, Add, Activation, Lambda
from tensorflow.keras import backend as K
from tensorflow.keras.activations import sigmoid
from tensorflow.keras.layers import Layer

class CBAM1DAttention(Layer):
    """
    Contains the implementation of Convolutional Block Attention Module(CBAM) block.
    As described in https://arxiv.org/abs/1807.06521.    
    """    
    def __init__(self, ratio=8, **kwargs):
        super().__init__(**kwargs)
        self.ratio = ratio
        self.channel_attention  = CBAM1DChannelAttention(self.ratio)
        self.temporal_attention = CBAM1DTemporalAttention()  
    # __init__

    def call(self, input_feature):
        output_feature = self.channel_attention(input_feature)
        output_feature = self.temporal_attention(output_feature)
        return output_feature
    # call

    def get_config(self):
        self.config = {
            "ratio": self.ratio,
        }
        return self.config
    # get_config    

    @classmethod
    def from_config(cls, config):
        return cls(**config)       
# CBAM1DAttention

class CBAM1DChannelAttention(Layer):
    def __init__(self, ratio=8, **kwargs):
        self.ratio = ratio
        super().__init__(**kwargs)
        pass
    # __init__

    def call(self, input_feature):
        channel_axis = 1 if K.image_data_format() == "channels_first" else -1
        channel = input_feature.shape[channel_axis]
        ratio = self.ratio

        shared_layer_one = Dense(channel // ratio,
                                activation='relu',
                                kernel_initializer='he_normal',
                                use_bias=True,
                                bias_initializer='zeros')
        shared_layer_two = Dense(channel,
                                kernel_initializer='he_normal',
                                use_bias=True,
                                bias_initializer='zeros')         

        avg_pool = GlobalAveragePooling1D()(input_feature)
        avg_pool = Reshape((1, channel))(avg_pool)
        assert avg_pool.shape[1:] == (1, channel)
        # print(avg_pool.shape[1:], (1, channel))

        avg_pool = shared_layer_one(avg_pool)
        assert avg_pool.shape[1:] == (1, channel // ratio)
        # print(avg_pool.shape[1:], (1, channel // ratio))

        avg_pool = shared_layer_two(avg_pool)
        assert avg_pool.shape[1:] == (1, channel)
        # print(avg_pool.shape[1:], (1, channel))

        max_pool = GlobalMaxPooling1D()(input_feature)
        max_pool = Reshape((1, channel))(max_pool)
        assert max_pool.shape[1:] == (1, channel)
        # print(max_pool.shape[1:], (1, channel))

        max_pool = shared_layer_one(max_pool)
        assert max_pool.shape[1:] == (1, channel // ratio)
        # print(max_pool.shape[1:], (1, channel // ratio))

        max_pool = shared_layer_two(max_pool)
        assert max_pool.shape[1:] == (1, channel)
        # print(max_pool.shape[1:], (1, channel))

        cbam_feature = Add()([avg_pool, max_pool])
        cbam_feature = Activation('sigmoid')(cbam_feature)
        # print(cbam_feature.shape[1: ])

        if K.image_data_format() == "channels_first":
            cbam_feature = Permute((2, 1))(cbam_feature)

        output_feature = multiply([input_feature, cbam_feature])
        return output_feature
    # call

    def get_config(self):
        self.config = {
            "ratio": self.ratio,
        }
        return self.config
    # get_config    

    @classmethod
    def from_config(cls, config):
        return cls(**config)   
# CBAM1DChannelAttention

class CBAM1DTemporalAttention(Layer):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        pass
    # __init__

    def call(self, input_feature): # batch_size, temporal, features
        channel_axis = 1 if K.image_data_format() == "channels_first" else len(input_feature.shape) - 1
        kernel_size = 7

        if K.image_data_format() == "channels_first":
            channel = input_feature.shape[1]
            cbam_feature = Permute((2, 1))(input_feature)
        else:
            channel = input_feature.shape[-1]
            cbam_feature = input_feature

        avg_pool = Lambda(lambda x: K.mean(x, axis=channel_axis, keepdims=True))(cbam_feature)
        assert avg_pool.shape[-1] == 1


        max_pool = Lambda(lambda x: K.max(x, axis=channel_axis, keepdims=True))(cbam_feature)
        assert max_pool.shape[-1] == 1

        concat = Concatenate(axis=channel_axis)([avg_pool, max_pool])
        assert concat.shape[-1] == 2
        
        cbam_feature = Conv1D(filters=1,
                            kernel_size=kernel_size,
                            strides=1,
                            padding='same',
                            activation='sigmoid',
                            kernel_initializer='he_normal',
                            use_bias=False)(concat)
        assert cbam_feature.shape[-1] == 1

        if K.image_data_format() == "channels_first":
            cbam_feature = Permute((1, 2))(cbam_feature)

        output_feature = multiply([input_feature, cbam_feature])
        return output_feature
    # call

    def get_config(self):
        self.config = {}
        return self.config
    # get_config    

    @classmethod
    def from_config(cls, config):
        return cls(**config)   
# CBAM1DTemporalAttention

class SqueezeExcitation1DAttention(Layer):
    """Contains the implementation of Squeeze-and-Excitation(SE) block.
    As described in https://arxiv.org/abs/1709.01507.
    """    
    def __init__(self, ratio=8, **kwargs):
        self.ratio = ratio
        super().__init__(**kwargs)
    # __init__    

    def call(self, input_feature): # batch_size, temporal, features
        ratio = self.ratio
        channel_axis = 1 if K.image_data_format() == "channels_first" else -1
        channel = input_feature.shape[channel_axis]

        se_feature = GlobalAveragePooling1D()(input_feature)
        se_feature = Reshape((1, channel))(se_feature)
        assert se_feature.shape[1:] == (1, channel)
        se_feature = Dense(channel // ratio,
                        activation='relu',
                        kernel_initializer='he_normal',
                        use_bias=True,
                        bias_initializer='zeros')(se_feature)
        assert se_feature.shape[1:] == (1, channel // ratio)
        se_feature = Dense(channel,
                        activation='sigmoid',
                        kernel_initializer='he_normal',
                        use_bias=True,
                        bias_initializer='zeros')(se_feature)
        assert se_feature.shape[1:] == (1, channel)
        if K.image_data_format() == 'channels_first':
            se_feature = Permute((2, 1))(se_feature)

        se_feature = multiply([input_feature, se_feature])
        return se_feature

    def get_config(self):
        self.config = {
            "ratio": self.ratio,
        }
        return self.config
    # get_config    

    @classmethod
    def from_config(cls, config):
        return cls(**config)   
# SqueezeExcitation1DAttention

def cbam1d_attention(input_feature, ratio = 0.8, **kwargs):
    output_feature = cbam1d_channel_attention(input_feature, ratio)
    output_feature = cbam1d_temporal_attention(output_feature)
    return output_feature
# cbam1d_attention

def cbam1d_channel_attention(input_feature, ratio = 0.8, **kwargs):
    channel_axis = 1 if K.image_data_format() == "channels_first" else -1
    channel = input_feature.shape[channel_axis]

    shared_layer_one = Dense(channel // ratio,
                            activation='relu',
                            kernel_initializer='he_normal',
                            use_bias=True,
                            bias_initializer='zeros')
    shared_layer_two = Dense(channel,
                            kernel_initializer='he_normal',
                            use_bias=True,
                            bias_initializer='zeros')         

    avg_pool = GlobalAveragePooling1D()(input_feature)
    avg_pool = Reshape((1, channel))(avg_pool)
    assert avg_pool.shape[1:] == (1, channel)
    # print(avg_pool.shape[1:], (1, channel))

    avg_pool = shared_layer_one(avg_pool)
    assert avg_pool.shape[1:] == (1, channel // ratio)
    # print(avg_pool.shape[1:], (1, channel // ratio))

    avg_pool = shared_layer_two(avg_pool)
    assert avg_pool.shape[1:] == (1, channel)
    # print(avg_pool.shape[1:], (1, channel))

    max_pool = GlobalMaxPooling1D()(input_feature)
    max_pool = Reshape((1, channel))(max_pool)
    assert max_pool.shape[1:] == (1, channel)
    # print(max_pool.shape[1:], (1, channel))

    max_pool = shared_layer_one(max_pool)
    assert max_pool.shape[1:] == (1, channel // ratio)
    # print(max_pool.shape[1:], (1, channel // ratio))

    max_pool = shared_layer_two(max_pool)
    assert max_pool.shape[1:] == (1, channel)
    # print(max_pool.shape[1:], (1, channel))

    cbam_feature = Add()([avg_pool, max_pool])
    cbam_feature = Activation('sigmoid')(cbam_feature)
    # print(cbam_feature.shape[1: ])

    if K.image_data_format() == "channels_first":
        cbam_feature = Permute((2, 1))(cbam_feature)

    output_feature = multiply([input_feature, cbam_feature])
    return output_feature    
# cbam1d_channel_attention

def cbam1d_temporal_attention(input_feature, **kwargs):
    channel_axis = 1 if K.image_data_format() == "channels_first" else len(input_feature.shape) - 1
    kernel_size = 7

    if K.image_data_format() == "channels_first":
        channel = input_feature.shape[1]
        cbam_feature = Permute((2, 1))(input_feature)
    else:
        channel = input_feature.shape[-1]
        cbam_feature = input_feature

    avg_pool = Lambda(lambda x: K.mean(x, axis=channel_axis, keepdims=True))(cbam_feature)
    assert avg_pool.shape[-1] == 1


    max_pool = Lambda(lambda x: K.max(x, axis=channel_axis, keepdims=True))(cbam_feature)
    assert max_pool.shape[-1] == 1

    concat = Concatenate(axis=channel_axis)([avg_pool, max_pool])
    assert concat.shape[-1] == 2
    
    cbam_feature = Conv1D(filters=1,
                        kernel_size=kernel_size,
                        strides=1,
                        padding='same',
                        activation='sigmoid',
                        kernel_initializer='he_normal',
                        use_bias=False)(concat)
    assert cbam_feature.shape[-1] == 1

    if K.image_data_format() == "channels_first":
        cbam_feature = Permute((1, 2))(cbam_feature)

    output_feature = multiply([input_feature, cbam_feature])
    return output_feature    
# cbam1d_temporal_attention

def squeeze_excitation1d_attention(x, ratio = 0.8, **kwargs):
    channel_axis = 1 if K.image_data_format() == "channels_first" else -1
    channel = input_feature.shape[channel_axis]

    se_feature = GlobalAveragePooling1D()(input_feature)
    se_feature = Reshape((1, channel))(se_feature)
    assert se_feature.shape[1:] == (1, channel)
    se_feature = Dense(channel // ratio,
                    activation='relu',
                    kernel_initializer='he_normal',
                    use_bias=True,
                    bias_initializer='zeros')(se_feature)
    assert se_feature.shape[1:] == (1, channel // ratio)
    se_feature = Dense(channel,
                    activation='sigmoid',
                    kernel_initializer='he_normal',
                    use_bias=True,
                    bias_initializer='zeros')(se_feature)
    assert se_feature.shape[1:] == (1, channel)
    if K.image_data_format() == 'channels_first':
        se_feature = Permute((2, 1))(se_feature)

    se_feature = multiply([input_feature, se_feature])
    return se_feature    
# squeeze_excitation1d_attention