import tensorflow as tf

from tensorflow.keras.layers import Input, Layer
from tensorflow.keras.models import Model, Sequential

from tensorflow.keras.layers import Conv1D, MaxPool1D, Activation, BatchNormalization
from tensorflow.keras.layers import GlobalAveragePooling1D, GlobalMaxPooling1D, GlobalAveragePooling2D

from esignal.tf2_keras.models.layers.cbam import cbam1d_attention, squeeze_excitation1d_attention

def lstm_temporal_block(x, class_name = 'lstm_temporal_block',
                        # (loop, filters, kernel, activation, has_batch_norm)
                        block_cfg = [(2,  64, 3, 'tanh', 'batch_norm',  'max_pool'),
                                       (2, 64, 3,  'tanh', 'batch_norm', 'max_pool'),
                                       (3, 128, 3, 'tanh', 'batch_norm', 'max_pool'),
                                       (3, 128, 3, 'tanh', 'batch_norm', 'max_pool'),
                                       (3, 256, 3, 'tanh', 'batch_norm', 'max_pool'),
                                       (3, 256, 3, 'tanh', 'batch_norm', 'max_pool'),
                          ],
                        ):
    pass
# lstm_block

def conv1d_temporal_block(x, class_name = 'conv1d_temporal_block',
                          # (loop, filters, kernel, activation, has_batch_norm)
                          block_cfg = [(2,  64, 3, 'tanh', 'batch_norm', 'max_pool'),
                                       (2,  64, 3, 'tanh', 'batch_norm', 'max_pool'),
                                       (3, 128, 3, 'tanh', 'batch_norm', 'max_pool'),
                                       (3, 128, 3, 'tanh', 'batch_norm', 'max_pool'),
                                       (3, 256, 3, 'tanh', 'batch_norm', 'max_pool'),
                                       (3, 256, 3, 'tanh', 'batch_norm', 'max_pool'),
                          ],
                          attention_module = 'cbam', # cbam, se
                          attention_params = {'ratio': 8 }, 
                          pooling = 'avg', 

                          ** kwargs):
    blocks = []
    for block_idx, block_info in enumerate(block_cfg):
        n_conv, n_filter, kernel, act_name, batch_norm, max_pool = block_info
        for conv_idx in range(n_conv - 1):
            x = Conv1D(n_filter, kernel, strides=1, padding='same', name = f'{class_name}_blk{block_idx}_conv{conv_idx}')(x)
            if act_name != '':
                x = Activation(act_name, name=f'{class_name}_blk{block_idx}_act{conv_idx}')(x)
        # for
        conv_idx = conv_idx + 1
        x = Conv1D(n_filter, kernel, strides=1, padding='same', name=f'{class_name}_blk{block_idx}_conv{conv_idx}')(x)
        if batch_norm != '':
            x = BatchNormalization(name=f'{class_name}_blk{block_idx}_norm')(x)
        if max_pool != '':
            x = MaxPool1D(pool_size=2, name=f'{class_name}_blk{block_idx}_pool')(x)
        if attention_module == "cbam":
            # x = CBAM1DAttention(name=f'{class_name}_blk{block_idx}_cbam', **attention_params)(x)
            x = cbam1d_attention(x, **attention_params)
        elif attention_module == "se":
            # x = SqueezeExcitation1DAttention(name=f'{class_name}_blk{block_idx}_se', **attention_params)(x)
            x = squeeze_excitation1d_attention(x, **attention_params)
            pass
        blocks.append(x)
    # for
    if pooling == 'avg':
        x = GlobalAveragePooling1D(name=f'{class_name}_blk{block_idx}_globalpool')(x)
    elif pooling == 'max':
        x = GlobalMaxPooling1D(name=f'{class_name}_blk{block_idx}_globalpool')(x)
    return x, blocks

