from IPython import display
import numpy as np
import pandas as pd
import tensorflow as tf

class KERC21Dataset:
    def __init__(self, data_cls,
                 data_names = ["val"], # ["train", "val", "test"]
                 data_filter ={"train": None, "val": None, "test": None}, # {"train": [indices], "val" : [...], "test": [...]}
                 data_features = {"x": ["eeg", "eda", "bvp", "temp", "personality"], "y": ["label_id_onehot"]},
                 filter_index = None,
                 verbose = 1,
                 x_preprocessing_fn = None,  # lambda key, pos, x : fn(x)
                 y_preprocessing_fn = None,
                 **kwargs):
        self.data_cls = data_cls
        self.data_names = data_names
        self.data_features = data_features
        self.data_filter = data_filter
        self.verbose = verbose
        self.x_preprocessing_fn = x_preprocessing_fn
        self.y_preprocessing_fn = y_preprocessing_fn
        self.filter_index = filter_index

        self.df_all_samples = []
        self.lbl_all_names = []
        for data_name in data_names:
            df_data = self.data_cls.df_samples.query(f"Name=='{data_name}'")
            idx_filter = self.data_filter.get(data_name)
            if idx_filter is None or len(idx_filter)==0: idx_filter = np.arange(len(df_data))
            df_data = df_data.iloc[idx_filter]
            lbl_names = [""] * len(df_data) if self.data_cls.df_labels.get(data_name) is None else \
                self.data_cls.df_labels[data_name]["label"].iloc[idx_filter].values

            self.df_all_samples.append(df_data)
            self.lbl_all_names.extend(lbl_names)
        # for

        self.df_all_samples = pd.concat(self.df_all_samples)
        self.lbl_all_names  = np.array(self.lbl_all_names)
        self.lbl_all_ids    = np.array([int(self.data_cls.label_sdic.get(name, -1)) for name in self.lbl_all_names])
        self.all_ids        = self.df_all_samples["Id"].values

        self.set_filter_index(self.filter_index)

        self.x_names = data_features.get("x", [])
        self.y_names = data_features.get("y", [])
        self.n_outputs = len(self.y_names)
        self.n_inputs  = len(self.x_names)

        self.global_scope = kwargs.get("global_scope", {})
        self.global_scope.update(**locals())
        pass

    def __len__ (self):
        return len(self.ids)
    # __len__

    def set_filter_index(self, filter_index = None):
        self.filter_index = filter_index
        if self.filter_index is not None:
            self.ids        = self.df_all_samples["Id"].iloc[self.filter_index].values
            self.df_samples = self.df_all_samples.iloc[self.filter_index]
            self.lbl_names  = self.lbl_all_names[self.filter_index]
            self.lbl_ids    = self.lbl_all_ids[self.filter_index]
        else:
            self.ids        = self.df_all_samples["Id"].values
            self.df_samples = self.df_all_samples
            self.lbl_names  = self.lbl_all_names
            self.lbl_ids    = self.lbl_all_ids

    # set_filter_index

    def preprocessing_fn(self):
        def default_preprocessing(key, x):
            return x
        return default_preprocessing
    # preprocessing_fn

    def __getitem__(self, index):
        sample_id = self.ids[index]
        result = self.data_cls.read_data_sample(sample_id)
        x, y = (), ()
        if self.x_preprocessing_fn is None:
            for feature in self.data_features["x"]:
                x += (result[feature],)
        else:
            for pos, feature in enumerate(self.data_features["x"]):
                x += (self.x_preprocessing_fn(feature, pos, result[feature]),)

        if self.y_preprocessing_fn is None:
            for feature in self.data_features["y"]:
                y += (result[feature],)
        else:
            for pos, feature in enumerate(self.data_features["y"]):
                y += (self.y_preprocessing_fn(feature, pos, result[feature]),)

        if self.verbose == 1: self.debug = dict(cur_index = index, sample_id = sample_id)
        return x, y
        pass
    # __getitem__

    def tf_parse_data (self, in_dtype=tf.float32, out_dtype=tf.float32):
        n_inputs = self.n_inputs
        n_outputs = self.n_outputs
        T_out = [in_dtype] * n_inputs + [out_dtype] * n_outputs

        def internal (idx):
            idx = idx.numpy()
            x, y = self[idx]
            return [*list(x), *list(y)]

        def tf_internal (idx):
            result = tf.py_function(internal, [idx], T_out)
            return tuple(result[:n_inputs]), tuple(result[n_inputs:])

        # tf_internal
        return tf_internal
    # tf_parse_data

    def to_dataset(self,
                   data_type = "train", # train ==> shuffle, repeat, valid ==> no shuffle and repeat
                   in_dtype=tf.float32, out_dtype=tf.float32, # mapping
                   num_parallel_calls=tf.data.AUTOTUNE, cycle_length=4, block_length=2, # interleave
                   batch_size=4, # batch (=0 --> no batch)
                   prefetch_size=tf.data.AUTOTUNE, # prefetch
                   shuffle_size=4, seed=None, # shuffle
                   ):
        def tf_map_fn(x):
            return tf.data.Dataset.from_tensors(x).map(self.tf_parse_data(in_dtype, out_dtype), num_parallel_calls=num_parallel_calls)

        ds = tf.data.Dataset.range(len(self))
        ds = ds.interleave(tf_map_fn, cycle_length=cycle_length, block_length=block_length)

        if data_type=="train":
            ds = ds.shuffle(buffer_size=shuffle_size, seed=seed, reshuffle_each_iteration=True).repeat()

        if batch_size>0:
            ds = ds.batch(batch_size=batch_size)

        ds = ds.prefetch(prefetch_size)
        return ds
    # to_train_dataset

# KERC21Dataset