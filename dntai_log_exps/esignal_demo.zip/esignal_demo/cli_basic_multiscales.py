import os, sys

# sklearn
from joblib import dump
from sklearn.model_selection import GridSearchCV, StratifiedKFold, RepeatedStratifiedKFold
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler, MinMaxScaler, RobustScaler
from sklearn.svm import SVC
from sklearn.ensemble import RandomForestClassifier, AdaBoostClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.utils.fixes import loguniform

from xgboost import XGBClassifier
import xgboost
import lightgbm
from lightgbm import LGBMClassifier

import catboost
from catboost import *


# script info
script_dir  = os.path.normpath(os.path.dirname(os.path.abspath(__file__))) # path to train.py
root_dir    = os.path.normpath(os.path.abspath(script_dir + "/.."))
source_dir  = root_dir

if source_dir in sys.path: sys.path.remove(source_dir)
sys.path.insert(1, source_dir)

from esignal.common import *
from esignal.utils import *

script_date = datetime.now()
script_sdate = f'{script_date:%y%m%d_%H%M%S}_{random.randint(0, 100):02}'

# skip warning
warnings.filterwarnings("ignore")

# common variables
label_ids  = np.array(['HAHV','HALV','LALV','LAHV'])
label_sdic = dict(zip(label_ids, range(len(label_ids))))
label_idic = dict(zip(range(len(label_ids)), label_ids))

def options_common(func):
    """
    https://stackoverflow.com/questions/5409450/can-i-combine-two-decorators-into-a-single-one-in-python
    """
    options  = [
        click.option("--logs-file", type=str, default="{root_dir}/logs/logs.txt"),
        click.option("--app-cfg", type=str, default=""),
        click.option("--evalf", type=str, multiple=True, default=['dataset_dir','logs_file']),
        click.option("--add-evalf", type=str, multiple=True, default=[]),
        click.option("--debug", type=int, default=0)
    ]
    for option in options: func = option(func)
    return func

def options_args(func):
    """
    https://stackoverflow.com/questions/5409450/can-i-combine-two-decorators-into-a-single-one-in-python
    """
    options  = [
        click.option("--dataset-dir", type=str, default="{root_dir}/data/KERC21Dataset/preprocessed"),
    ]
    for option in options: func = option(func)
    return func

def process_options(ctx, **params):
    # init params
    ctx.obj["params"].update(**params)
    params = ctx.obj["params"]

    for k in ['script_dir', 'script_date', 'script_sdate', 'root_dir', 'source_dir']:
        if params.get(k) is None: params[k] = globals()[k]

    params['evalf'] = list(params['evalf'])
    params['evalf'].extend(list(params['add_evalf']))
    params['evalf'].append('logs_file')
    for k in params['evalf']:
        if params.get(k) is not None:
            params[k] = eval("f'%s'" % (params[k]), {**globals(), **locals(), **params})

    logs_dir = os.path.dirname(params["logs_file"])
    if logs_dir != "" and os.path.exists(logs_dir) == False: os.makedirs(logs_dir)
    tee_log.append(f'{params["logs_file"]}')
    print(f'[Program Start]\n+ Script Date: {script_sdate}')
    print(f'\n[Command {ctx.command.name}]')

    print('params: ')
    for k in params: print(f'+ {k}: {pformat(params[k])}')

    if params["debug"] == 1: raise Exception(f'Exit Debug Options')

    globals()["params"] = params
    return params

@click.group(invoke_without_command=True)
@click.pass_context
def main(ctx, **params):
    ctx.ensure_object(dict)

@main.command(context_settings=dict(ignore_unknown_options=True, allow_extra_args = True), name = 'export-ids')
@click.option("--dataset-dir", type=str, default="{root_dir}/data/KERC21Dataset/preprocessed")
@click.option("--export-dir", type=str, default="{root_dir}/data/KERC21Dataset/preprocessed")
@click.option("--db-names", type=str, multiple=True, default=['train', 'val', 'test'])
@options_common
@click.option("--add-evalf", type=str, multiple=True, default=['export_dir'])
@click.pass_context
def main_export_ids(ctx, **params):
    params = process_options(ctx, **params)
    print("\nexport ids: ")
    for db_name in params["db_names"]:
        ids = pd.read_csv(f'{params["dataset_dir"]}/{db_name}_personality.csv')['Id'].values
        if params["export_dir"] != "" and os.path.exists(params["export_dir"]) == False: os.makedirs(params["export_dir"])
        np.savetxt(f'{params["export_dir"]}/{db_name}_ids.txt', ids, fmt='%s')
        print(f'+ [{db_name}] {params["export_dir"]}/{db_name}_ids.txt!')
# main_export_ids

@main.command(context_settings=dict(ignore_unknown_options=True, allow_extra_args = True), name = 'index-feats')
@click.option("--dataset-dir", type=str, default="{root_dir}/data/KERC21Dataset")
@click.option("--feats-dir", type=str, default="{root_dir}/data/KERC21Dataset/preprocessed/baseline")
@click.option("--ids-dir", type=str, default="{root_dir}/data/KERC21Dataset/preprocessed")
@click.option("--export-dir", type=str, default="{dataset_dir}/features")
@click.option("--export-name", type=str, default="{db_name}_feats.hdf")
@click.option("--db-names", type=str, multiple=True, default=['train', 'val', 'test'])
@click.option("--db-feats", type=str, multiple=True, default=['EEG_ftrs','BVP','EDA'])
@options_common
@click.option("--add-evalf", type=str, multiple=True, default=['export_dir', 'ids_dir', 'feats_dir'])
@click.pass_context
def main_index_feats(ctx, **params):
    params = process_options(ctx, **params)

    print('\nIndex Data')
    for db_name in params["db_names"]:
        print(f"\n==> Index {db_name}: ")

        # load ids
        db_ids = np.loadtxt(f'{params["ids_dir"]}/{db_name}_ids.txt', dtype=str)

        # label info
        label_path = f'{params["dataset_dir"]}/{db_name}_labels.csv'
        if os.path.exists(label_path) == True:
            df_labels = pd.read_csv(label_path)
            df_labels = df_labels.set_index(['Id'])
        else:
            df_labels = None

        # pernality info
        personality_path = f'{params["dataset_dir"]}/{db_name}_personality.csv'
        df_personality = pd.read_csv(personality_path)
        # display.display(df_personality)
        df_personality = df_personality.set_index(['Id'])

        db_data = []
        for db_id in db_ids:
            row_info = {}
            row_info["id"] = db_id

            # classify
            if df_labels is not None:
                row_info['label_id'] = label_sdic[df_labels.loc[db_id]['label']]
                row_info['label_name'] = df_labels.loc[db_id]['label']
            else:
                row_info['label_id'] = ''
                row_info['label_name'] = ''

            # features
            for db_feat in params["db_feats"]:
                row_info[db_feat] = np.load(f'{params["feats_dir"]}/{db_name}/{db_id}_{db_feat}.npy')

            for k, v in df_personality.loc[db_id].items(): row_info[k] = v
            db_data.append(row_info)
        # for ids
        df_data = pd.DataFrame(db_data)
        print(f'+ {db_name} has {len(df_data)} rows.')
        if params["export_dir"] != "" and os.path.exists(params["export_dir"]) == False:  os.makedirs(params["export_dir"])
        save_path = f'{params["export_dir"]}/{params["export_name"].format(**{"db_name": db_name})}'
        print(f'Save path: {save_path}')
        df_data.to_hdf(save_path, key = 'data')
    # for db_name
# main_index_feats

# 'EEG_ftrs', 'BVP', 'EDA', ('Extraversion', 'Neuroticism', 'Conscientiousness', 'Agreeableness', 'Openness') (personality)
@main.command(context_settings=dict(ignore_unknown_options=True, allow_extra_args = True), name = 'build-feats')
@click.option("--feats-dir", type=str, default="{root_dir}/data/KERC21Dataset/preprocessed/features")
@click.option("--feats-name", type=str, default="{db_name}_feats.hdf")
@click.option("--export-dir", type=str, default="{root_dir}/data/KERC21Dataset/preprocessed/features")
@click.option("--export-name", type=str, default="feats_eegftrs_bvp_eda_pe_one1.npz")
@click.option("--train-set", type=str, multiple=True, default=['train'])
@click.option("--test-set", type=str, multiple=True, default=['val', 'test'])
@click.option("--feat-names", type=str, multiple=True, default=['EEG_ftrs','BVP','EDA', 'personality'])
@click.option("--one-hot", type=int, default=1)
@options_common
@click.option("--logs-file", type=str, default="{export_dir}/{export_name}.txt")
@click.option("--add-evalf", type=str, multiple=True, default=['feats_dir', 'export_dir'])
@click.pass_context
def main_build_feats(ctx, **params):
    params = process_options(ctx, **params)

    train_set = params["train_set"]
    test_set = params["test_set"]
    has_one_hot = params["one_hot"] == 1
    feat_names = params["feat_names"]
    feat_personality = ('Extraversion', 'Neuroticism', 'Conscientiousness', 'Agreeableness', 'Openness')
    one_hot_mask = np.array([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, 0], [0, 0, 0, 1]])

    feat_path = f'{params["feats_dir"]}/{params["feats_name"]}'
    print(feat_path)
    df_train = pd.DataFrame()
    print("\nLoad Train set: ")
    for db_name in train_set:
        df_load = pd.read_hdf(feat_path.format(**{"db_name": db_name}))
        df_train = pd.concat([df_train, df_load], axis=0)
        print(f'[{db_name}] ({len(df_load)} rows)', end = "")
    print(f" - Total: {len(df_train)} rows")

    print("\nLoad Test set: ")
    df_test = pd.DataFrame()
    for db_name in test_set:
        df_load = pd.read_hdf(feat_path.format(**{"db_name": db_name}))
        df_test = pd.concat([df_test, df_load], axis=0)
        print(f'[{db_name}] ({len(df_load)} rows)', end="")
    print(f" - Total: {len(df_test)} rows")

    # data
    df_data = {"train": df_train, "test": df_test}
    feat_all = []
    for feat_name in feat_names:
        if feat_name == "personality":
            feat_all.extend(feat_personality)
        else:
            feat_all.append(feat_name)

    # feature selection
    X = {}
    y = {}
    X["X_train_ids"] = df_train["id"].values
    X["X_test_ids"]  = df_test["id"].values
    for x_type in ["train", "test"]:
        merge_feat = []
        for feat_name in feat_all:
            if feat_name == "personality": feat_name = list(feat_personality)
            # make sure two dims (num_rows, num_dims)
            n_size = len(df_data[x_type])
            row0 = np.array([df_data[x_type][feat_name].values[0]])
            n_dim = int(np.prod(row0.shape))
            data_feat = df_data[x_type][feat_name].values
            if feat_name in feat_personality and has_one_hot is True:
                data_feat = one_hot_mask[data_feat]
                n_dim = n_dim * one_hot_mask.shape[0]
            one_feat = np.vstack(data_feat).reshape(n_size, n_dim)
            # append
            merge_feat.append(one_feat)

        # merge
        merge_feat = np.hstack(merge_feat)
        X[x_type] = merge_feat.astype(np.float)
        y[x_type] = df_data[x_type]["label_id"].values
        y[x_type][y[x_type] == ''] = -1
        y[x_type] = y[x_type].astype(np.int)
    # for

    if params["export_dir"] != "" and os.path.exists(params["export_dir"]) == False:  os.makedirs(params["export_dir"])

    save_data = {"X_train": X["train"], "y_train": y["train"], "X_test": X["test"], "y_test": y["test"]}
    save_data["X_train_ids"] = df_train["id"].values
    save_data["X_test_ids"]  = df_test["id"].values

    save_path = f'{params["export_dir"]}/{params["export_name"]}'
    np.savez(save_path, **save_data)

    print(f"\nSaving features: {save_path}")
    print(f'+ X_train: {X["train"].shape}, y_train: {y["train"].shape}')
    print(f'+ X_test: {X["test"].shape}, y_test: {y["test"].shape}')
    print(f'+ Keys: {list(save_data.keys())}')
# main_build_feats


# 'EEG_ftrs', 'BVP', 'EDA', ('Extraversion', 'Neuroticism', 'Conscientiousness', 'Agreeableness', 'Openness') (personality)
@main.command(context_settings=dict(ignore_unknown_options=True, allow_extra_args = True), name = 'train-pipeline')
@click.option("--feats-dir", type=str, default="{root_dir}/data/KERC21Dataset/preprocessed/features")
@click.option("--feats-name", type=str, default="feats_eegftrs_bvp_eda_pe_one0")
@click.option("--model-name", type=str, default="svm")
@click.option("--expr-dir", type=str, default="{root_dir}/logs/{model_name}_{feats_name}_{script_sdate}")
@click.option("--save-name", type=str, default="submission_team.csv")
@click.option("--seed", type=int, default=0)
@click.option("--k-fold", type=int, default=10)
@click.option("--n-repeats", type=int, default=2)
@click.option("--scaler", type=str, default="StandardScaler") # StandardScaler, MinMaxScaler, RobustScaler
@options_common
@click.option("--logs-file", type=str, default="{expr_dir}/logs.txt")
@click.option("--evalf", type=str, multiple=True, default=['feats_dir', 'export_dir', 'expr_dir'])
@click.pass_context
def main_train_pipeline(ctx, **params):
    params = process_options(ctx, **params)

    # Load data
    feats_dir = f'{root_dir}/data/KERC21Dataset/preprocessed/features'
    selfeats_file = f'feats_eegftrs_bvp_eda_pe_one0.npz'

    selfeats_path = f'{params["feats_dir"]}/{params["feats_name"]}.npz'
    result = dict(np.load(selfeats_path, allow_pickle=True))

    X_train, y_train, X_test, y_test = result["X_train"], result["y_train"], result["X_test"], result["y_test"]
    X_train_ids, X_test_ids = result["X_train_ids"], result["X_test_ids"]
    print(f'X_train: {X_train.shape}, y_train: {y_train.shape}')
    print(f'X_test: {X_test.shape}, y_test: {y_test.shape}')

    # Prepare Model
    model_name = params["model_name"]
    print(f'\nGridsearch CV for {params["model_name"]}')

    # kfold
    cv = RepeatedStratifiedKFold(n_splits=params["k_fold"], n_repeats=params["n_repeats"], random_state=params["seed"])
    print(f'==> k-fold: n_splits={params["k_fold"]}, n_repeats={params["n_repeats"]}, random_state={params["seed"]}')

    # scaler
    if params["scaler"] == "StandardScaler":
        scaler_cls = StandardScaler()
    elif params["scaler"] == "MinMaxScaler":
        scaler_cls = MinMaxScaler()
    elif params["scaler"] == "RobustScaler":
        scaler_cls = MinMaxScaler()
    print(f'==> scaler: {params["scaler"]}')

    # model
    if model_name == "svm":
        print("==> SVM Init")
        # model_clf = SVC(decision_function_shape='ovr', class_weight='balanced', random_state=params["seed"])
        model_clf = SVC(decision_function_shape='ovr', class_weight='balanced', random_state=params["seed"], probability = True)
        parameters = {'svc__kernel': ['linear', 'rbf', 'sigmoid', 'poly'], 'svc__C': [1, 10, 50, 70, 100], 'svc__gamma': [1e-3, 1e-4, 1e-2]}
        print(f'==> Params: {parameters}')
    elif model_name == 'xgboost':
        print("==> XGBoost Init")
        model_clf = xgboost.XGBClassifier(random_state=params["seed"], gpu_id=0, tree_method = 'gpu_hist')
        parameters = {'xgbclassifier__n_estimators': [100, 300, 500],
                      'xgbclassifier__learning_rate': [0.01, 0.1, 0.001],
                      'xgbclassifier__max_depth': [10, -1, 20],
                      'xgbclassifier__subsample': [1, 2],
                      'xgbclassifier__colsample_bytree': [1, 2],
                      'xgbclassifier__colsample_bylevel': [1, 2],
                      'xgbclassifier__objective': ['multi:softmax']}
        print(f'==> Params: {parameters}')
    elif model_name == 'lightgbm':
        print("==> LightGBM Init")
        model_clf = lightgbm.LGBMClassifier(random_state=params["seed"])
        parameters = {'lgbmclassifier__n_estimators': [100, 300, 500],
                      'lgbmclassifier__learning_rate': [0.1, 0.01, 0.2, 0.001],
                      'lgbmclassifier__max_depth': [15, -1, 20],
                      'lgbmclassifier__subsample': [1, 2],
                      'lgbmclassifier__colsample_bytree': [1, 2],
                      'lgbmclassifier__subsample_freq': [0, 1],
                      'lgbmclassifier__objective': ['multiclass']}
        print(f'==> Params: {parameters}')
    elif model_name == 'catboost':
        print("==> CatBoost Init")
        model_clf = catboost.CatBoostClassifier()
        parameters = {
            'catboostclassifier__iterations': [500],
            'catboostclassifier__learning_rate' : [0.01,0.02,0.03,0.04],
            'catboostclassifier__depth': [4, 5, 6],
            'catboostclassifier__loss_function': ['MultiClass'],
            'catboostclassifier__l2_leaf_reg': np.logspace(-20, -19, 3),
            'catboostclassifier__leaf_estimation_iterations': [10],
            'catboostclassifier__logging_level':['Silent'],
        }
        pass

    print("==> Processing")

    # estimator
    estimator = make_pipeline(scaler_cls, model_clf)

    # grid search
    clf = GridSearchCV(estimator=estimator, param_grid=parameters,
                       scoring = {'f1': 'f1_micro', 'acc': 'accuracy'}, n_jobs = 20, cv = cv,
                       refit = 'f1', verbose = 10)

    # fit
    clf.fit(X_train, y_train)

    # print result
    print('Best score using {}: {}'.format(model_name, clf.best_score_))

    print(" Results from Grid Search " )
    print("\n The best estimator across ALL searched params:\n",clf.best_estimator_)
    print("\n The best score across ALL searched params:\n",clf.best_score_)
    print("\n The best parameters across ALL searched params:\n",clf.best_params_)    

    # Dump and save cls fit
    print(f'Saving cls [{os.path.join(params["expr_dir"], "best_clf.joblib")}]')
    dump(clf, os.path.join(params["expr_dir"], 'best_clf.joblib'))


    # Prediction
    y_test_pred = clf.predict(X_test)
    labels_pred = label_ids[y_test_pred]
    df_result = pd.DataFrame(np.stack([X_test_ids, labels_pred], axis=-1), columns=['Id', 'Predicted'])
    df_result.to_csv(f'{params["expr_dir"]}/{params["save_name"]}', index=False)

    print(f'Saving submission: {params["expr_dir"]}/{params["save_name"]}')
    print(f'+ Total: {len(X_test)}')
# main_train_pipeline

@main.command(context_settings=dict(ignore_unknown_options=True, allow_extra_args = True), name = 'test')
@options_args
@options_common
@click.pass_context
def main_test(ctx, **params):
    process_options(ctx, **params)
    pass
# main_test

if __name__ == "__main__":
    ctx_obj = {"tee_log": None, "params": {}, "global_scope": globals()}
    try:
        with TeeLog() as tee_log:
            ctx_obj["tee_log"] = tee_log
            main(obj=ctx_obj)
    except SystemExit as ex:
        with TeeLog(ctx_obj["params"]["logs_file"], "at") as tee_log:
            print(f'\n[Program Exit]\n+ Exit Code: {ex}')