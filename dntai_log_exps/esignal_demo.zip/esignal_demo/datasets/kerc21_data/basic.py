import os
import numpy as np
import pandas as pd
from IPython import display

# common variables
default_data_names = ['train', 'val', 'test']
default_data_types = ['train', 'val', 'test']
default_personality_cols = ["Extraversion", "Neuroticism", "Conscientiousness", "Agreeableness", "Openness"]
default_eeg_cols = ['AF3', 'F7', 'F3', 'FC5', 'T7', 'P7', 'O1', 'O2', 'P8', 'T8', 'FC6', 'F4', 'F8', 'AF4']

label_ids  = np.array(['HAHV','HALV','LALV','LAHV'])
label_sdic = dict(zip(label_ids, range(len(label_ids))))
label_idic = dict(zip(range(len(label_ids)), label_ids))

class KERC21Data:
    def __init__(self, data_dir, 
                        data_names = default_data_names, 
                        data_types = default_data_types, 
                        extra_feat_dirs  = [], # list features dir
                        extra_feat_cfgs  = [], # list features name in folder [["<name>", [file1, file2]]]
                        ):
        self.data_dir   = data_dir
        self.data_names = data_names
        self.data_types = data_types
        
        self.extra_feat_dirs  = extra_feat_dirs
        self.extra_feat_cfgs = extra_feat_cfgs

        self.label_ids = label_ids
        self.label_sdic = label_sdic
        self.label_idic = label_idic
        self.n_classes = len(self.label_ids)

        self.personality_cols = default_personality_cols
        self.eeg_cols = default_eeg_cols

        self.df_personality = {}
        self.df_labels      = {}
        sample_info = {"Index": [], "Id": [], "Name": [], "Type": []}
        for data_name, data_type in zip(self.data_names, self.data_types):
            personality_path = f'{self.data_dir}/{data_name}_personality.csv'
            self.df_personality[data_name] = pd.read_csv(personality_path)
            self.df_personality[data_name].set_index(['Id'], inplace = True, drop = False)
            if self.personality_cols is None:
                self.personality_cols = self.df_personality[data_name].columns[1:].values.astype(np.str)

            sample_ids = self.df_personality[data_name]["Id"].values.astype(np.str)
            sample_info["Index"].extend(range(len(sample_ids)))
            sample_info["Id"].extend(sample_ids)
            sample_info["Name"].extend([data_name] * len(sample_ids))
            sample_info["Type"].extend([data_type] * len(sample_ids))

            label_path = f'{self.data_dir}/{data_name}_labels.csv'
            self.df_labels[data_name] = None
            if os.path.exists(label_path) == True:
                self.df_labels[data_name] = pd.read_csv(label_path)
                self.df_labels[data_name].set_index(['Id'], inplace=True, drop=False)
        # for
        self.df_samples = pd.DataFrame(sample_info).set_index("Id", drop = False)

        self.read_data_index(index = 0, data_name = data_names[0])
        pass
    # __init__

    def get_len(self, data_name):
        return len(self.df_personality[data_name])
    # get_len

    def read_data_sample(self, sample_id):
        sample_info = self.df_samples.loc[sample_id]
        return self.read_data_index(index = sample_info["Index"], data_name = sample_info["Name"])
    # read_data

    def read_data_index(self, index, data_name):
        result       = { }
        sample_id    = self.df_personality[data_name]["Id"].iloc[index]
        sample_label = None if self.df_labels.get(data_name) is None else self.df_labels[data_name].loc[sample_id]["label"]

        df_eeg    = pd.read_csv(f'{self.data_dir}/{data_name}/{sample_id}/EEG_256.csv')
        # if self.eeg_cols is None: self.eeg_cols = df_eeg.columns.values.astype(np.str)
        feat_eeg  = df_eeg.values

        feat_bvp  = pd.read_csv(f'{self.data_dir}/{data_name}/{sample_id}/BVP_64.csv', header=None, squeeze=True).values
        feat_eda  = pd.read_csv(f'{self.data_dir}/{data_name}/{sample_id}/EDA_4.csv', header=None, squeeze=True).values
        feat_temp = pd.read_csv(f'{self.data_dir}/{data_name}/{sample_id}/TEMP_4.csv', header=None, squeeze=True).values

        feat_personality = self.df_personality[data_name][self.personality_cols].loc[sample_id].values.astype(np.int)

        result["id"]   = sample_id
        result["eeg"]  = feat_eeg
        result["bvp"]  = feat_bvp
        result["eda"]  = feat_eda
        result["temp"] = feat_temp
        result["personality"] = feat_personality
        # for idx in range(len(default_personality_cols)):
        #     result[default_personality_cols[idx]] = feat_personality[idx]
        if self.df_labels.get(data_name) is not None:
            result["label"] = sample_label
            result["label_id"] = self.label_sdic[sample_label]
            result["label_id_onehot"] = np.zeros(self.n_classes)
            result["label_id_onehot"][result["label_id"]] = 1
        else:
            result["label"] = None
            result["label_id"] = []
            result["label_id_onehot"] = []

        for feature_dir, feat_cfg in zip(self.extra_feat_dirs, self.extra_feat_cfgs):
            feature_name  = feat_cfg[0]
            feature_files = feat_cfg[1:]
            for feature_file in feature_files:
                basename, ext = os.path.splitext(feature_file)
                if ext == ".csv":
                    extra_feature = pd.read_csv(f'{feature_dir}/{data_name}/{sample_id}/{feature_file}', header=None, squeeze=True).values
                elif ext == ".npy":
                    extra_feature = np.load(f'{feature_dir}/{data_name}/{sample_id}/{feature_file}')
                result[f"{feature_name}_{basename}"] = extra_feature
        # for

        return result
    # read_data_index
# KERC21Data

