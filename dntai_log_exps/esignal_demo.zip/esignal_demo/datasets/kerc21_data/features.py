import os, numpy as np
import pandas as pd
from tqdm import tqdm

from esignal.features import *

def build_feat_baseline_fn(features, eeg_sampling_freq =256, eda_sr = 4, bvp_sr = 64,
                           personality_onehot = False,  personality_clas = 4):
    feat = {}
    feat["eeg"] = get_eeg_features(features["eeg"].T, eeg_sampling_freq)
    feat["eda"] = get_gsr_features(features["eda"], eda_sr)
    feat["bvp"] = get_bvp_features(features["bvp"], bvp_sr)
    if personality_onehot == True:
        feat["personality"] = get_one_hot(features["personality"], personality_clas)
    else:
        feat["personality"] = features["personality"]

    return feat
# build_feat_baseline_fn

def build_feat_baseline(data_cls, export_dir, eeg_sampling_freq =256, eda_sr = 4, bvp_sr = 64):
    print("Feature Extraction Baseline")
    for data_name in data_cls.data_names:
        export_db_dir = f'{export_dir}/{data_name}'
        if export_db_dir != "" and os.path.exists(export_db_dir) == False:
            os.makedirs(export_db_dir)

        n_data = data_cls.get_len(data_name)
        for index in tqdm(range(n_data), desc=f"{data_name}"):
            result = data_cls.read_data_index(index, data_name)
            features = build_feat_baseline_fn(result, eeg_sampling_freq = eeg_sampling_freq, eda_sr = eda_sr, bvp_sr = bvp_sr)
            np.save(f'{export_db_dir}/{result["id"]}_EEG_ftrs.npy', features["eeg"])
            np.save(f'{export_db_dir}/{result["id"]}_EDA.npy', features["eda"])
            np.save(f'{export_db_dir}/{result["id"]}_BVP.npy', features["bvp"])
        # for
    # for
    print("Finish!")
# build_feat_baseline

def build_feat_baseline_scales_fn(features, eeg_sampling_freq =256, eeg_scales = [8,4,2,1],
                              eda_sr = 4, eda_scales = [8, 4, 2, 1],
                              bvp_sr = 64, bvp_scales = [2, 1],
                              personality_onehot = False,
                              personality_clas = 4,
                              pooling = 'concat', ):
    feat = {}
    feat["eeg"] = get_eeg_features_scales(features["eeg"], eeg_sampling_freq, eeg_scales, pooling)
    feat["eda"] = get_eda_features_scales(features["eda"], eda_sr, eda_scales, pooling)
    feat["bvp"] = get_bvp_features_scales(features["bvp"], bvp_sr, bvp_scales, pooling)
    if personality_onehot == True:
        feat["personality"] = get_one_hot(features["personality"], personality_clas)
    else:
        feat["personality"] = features["personality"]

    return feat
# build_feat_baseline_scales_fn

def build_feat_temp_baseline_scales_fn(features, eeg_sampling_freq =256, eeg_scales = [8,4,2,1],
                                       eda_sr = 4, eda_scales = [8, 4, 2, 1],
                                       bvp_sr = 64, bvp_scales = [2, 1],
                                       temp_sr = 4, temp_scales = [2, 1],
                                       personality_onehot = False,
                                       personality_clas = 4,
                                       pooling = 'concat', ):
    feat = {}
    feat["eeg"] = get_eeg_features_scales(features["eeg"], eeg_sampling_freq, eeg_scales, pooling)
    feat["eda"] = get_eda_features_scales(features["eda"], eda_sr, eda_scales, pooling)
    feat["bvp"] = get_bvp_features_scales(features["bvp"], bvp_sr, bvp_scales, pooling)
    feat["temp"] = get_temp_features_scales(features["temp"], temp_sr, temp_scales, pooling)
    if personality_onehot == True:
        feat["personality"] = get_one_hot(features["personality"], personality_clas)
    else:
        feat["personality"] = features["personality"]

    return feat
# build_feat_temp_baseline_scales_fn


def build_feat_baseline_scales(data_cls, export_dir,
                        eeg_sampling_freq =256, eeg_scales = [8,4,2,1],
                        eda_sr = 4, eda_scales = [8, 4, 2, 1],
                        bvp_sr = 64, bvp_scales = [2, 1],
                        pooling = 'concat', ):
    print("Feature Extraction Baseline")
    for data_name in data_cls.data_names:
        export_db_dir = f'{export_dir}/{data_name}'
        if export_db_dir != "" and os.path.exists(export_db_dir) == False:
            os.makedirs(export_db_dir)

        n_data = data_cls.get_len(data_name)
        for index in tqdm(range(n_data), desc=f"{data_name}"):
            result = data_cls.read_data_index(index, data_name)
            features = build_feat_baseline_scales_fn(result,
                            eeg_sampling_freq =eeg_sampling_freq, eeg_scales = eeg_scales,
                            eda_sr = eda_sr, eda_scales = eda_scales,
                            bvp_sr = bvp_sr, bvp_scales = bvp_scales,
                            pooling = pooling, )
            np.save(f'{export_db_dir}/{result["id"]}_EEG_ftrs.npy', features["eeg"])
            np.save(f'{export_db_dir}/{result["id"]}_EDA.npy', features["eda"])
            np.save(f'{export_db_dir}/{result["id"]}_BVP.npy', features["bvp"])
        # for
    # for
    print("Finish!")
# build_feat_baseline_scales

def build_feat_temp_baseline_scales(data_cls, export_dir,
                                    eeg_sampling_freq =256, eeg_scales = [8,4,2,1],
                                    eda_sr = 4, eda_scales = [8, 4, 2, 1],
                                    bvp_sr = 64, bvp_scales = [2, 1],
                                    temp_sr = 64, temp_scales = [2, 1],
                                    pooling = 'concat', ):
    print("Feature Extraction Baseline")
    for data_name in data_cls.data_names:
        export_db_dir = f'{export_dir}/{data_name}'
        if export_db_dir != "" and os.path.exists(export_db_dir) == False:
            os.makedirs(export_db_dir)

        n_data = data_cls.get_len(data_name)
        for index in tqdm(range(n_data), desc=f"{data_name}"):
            result = data_cls.read_data_index(index, data_name)
            features = build_feat_temp_baseline_scales_fn(result,
                                                          eeg_sampling_freq =eeg_sampling_freq, eeg_scales = eeg_scales,
                                                          eda_sr = eda_sr, eda_scales = eda_scales,
                                                          bvp_sr = bvp_sr, bvp_scales = bvp_scales,
                                                          temp_sr = temp_sr, temp_scales = temp_scales,
                                                          pooling = pooling, )
            np.save(f'{export_db_dir}/{result["id"]}_EEG_ftrs.npy', features["eeg"])
            np.save(f'{export_db_dir}/{result["id"]}_EDA.npy', features["eda"])
            np.save(f'{export_db_dir}/{result["id"]}_BVP.npy', features["bvp"])
            np.save(f'{export_db_dir}/{result["id"]}_TEMP.npy', features["temp"])
        # for
    # for
    print("Finish!")
# build_feat_temp_baseline_scales

DEFAULT_FEATURE_CFGS = {
    # sampling_freq 256
    "eeg" : { "multiscales": [8,4,2,1], 
        "fn_name": "get_eeg_features_trans", "fn_params": [256], 
        "pooling" : "concat", "output_name": "EEG_ftrs", 
    },
    # eda sr = 4
    "eda" : { "multiscales": [8,4,2,1], 
        "fn_name": "get_gsr_features", "fn_params": [4], 
        "pooling" : "concat", "output_name": "EDA", 
    },    
    # bvp sr = 64
    "bvp" : { "multiscales": [2,1], 
        "fn_name": "get_bvp_features", "fn_params": [64], 
        "pooling" : "concat", "output_name": "BVP", 
    },      
    # temp sr = 64
    "temp" : { "multiscales": [2,1], 
        "fn_name": "get_hst_features", "fn_params": [64], 
        "pooling" : "concat", "output_name": "TEMP", 
    },
    # onehot class = 4
    "onehot" : { "multiscales": [1], 
        "fn_name": "get_one_hot", "fn_params": [4], 
        "pooling" : "concat", "output_name": "{feat_name}_onehot", 
    },    
    # temp sr = 64
    "default" : { "multiscales": [1], 
        "fn_name": "", "fn_params": [], 
        "pooling" : "concat", "output_name": "{feat_name}", 
    },    
}

def build_feat_extra_baseline_scales_fn(features, 
                                        feat_infos = [], # [(feat_name, cfg_name, extra_cfg), (feat_name, cfg_name), feat_name, ..] or default
                                        feat_cfgs  = DEFAULT_FEATURE_CFGS, # cfgs: {name: {multiscales: [1], fn_name: "{id}", fn_params: [], pooling = concat, output_name = [feat_name]) 
                                       ):
    feat = {}
    for feat_info in feat_infos:
        
        feature_cfg       = None
        feature_cfg_extra = {}
        if type(feat_info) is str:
            feature_name = feat_info
        elif type(feat_info) is tuple or type(feat_info) is list:
            feature_name = feat_info[0]
            if len(feat_info)>=2:
                feature_cfg  = feat_cfgs.get(feat_info[1])
            if len(feat_info)>=3:
                feature_cfg_extra  = feat_info[2]
        
        if feature_cfg is None:
            feature_cfg = feat_cfgs.get(feature_name, feat_cfgs.get("default", {}))
        feature_cfg.update(**feature_cfg_extra)
        
        pooling = feature_cfg.get('pooling', 'concat')
        multiscales = feature_cfg.get('multiscales', [1])

        feature_output = feature_cfg.get('output_name', "{feat_name}")
        feature_output = feature_output.replace("{feat_name}", feature_name)

        fn_name     = feature_cfg.get('fn_name')
        fn_params   = feature_cfg.get('fn_params', [])
        get_data_fn = eval(fn_name) if type(fn_name) is str and fn_name!="" else None
        fn_data     = lambda data: get_data_fn(data, *fn_params) if get_data_fn is not None else data

        feat_data   = build_multiscales(features[feature_name], fn_data, multiscales, pooling)
        feat[feature_output] = feat_data

    return feat
# build_feat_extra_baseline_scales_fn

def build_feat_extra_baseline_scales(data_cls, export_dir,
                                        feat_infos = [], # [(feat_name, cfg_name), feat_name, ...] or default
                                        feat_cfgs  = DEFAULT_FEATURE_CFGS, # cfgs: {name: {multiscales: [1], fn_name: "{id}", fn_params: [], pooling = concat)
                                        global_scope = None, **kwargs):
    print("Feature Extraction Baseline")
    for data_name in data_cls.data_names:
        export_db_dir = f'{export_dir}/{data_name}'
        if export_db_dir != "" and os.path.exists(export_db_dir) == False:
            os.makedirs(export_db_dir)

        n_data = data_cls.get_len(data_name)
        for index in tqdm(range(n_data), desc=f"{data_name}"):
            result = data_cls.read_data_index(index, data_name)
            features = build_feat_extra_baseline_scales_fn(result,
                                                           feat_infos = feat_infos, 
                                                           feat_cfgs = feat_cfgs, )
            for feat_name in features:
                np.save(f'{export_db_dir}/{result["id"]}_{feat_name}.npy', features[feat_name])

        # for
    # for
    print("Finish!")
# build_feat_extra_baseline_scales_fn

def eda_stat_features(data_cls, data_names = "train",
                      stat_features = ["eeg", "eda", "temp", "bvp", "personality"],
                      stat_types    = [2, -1, -1, -1, -2],
                      stat_names    = ["mean", "std"],
                      export_dir    = "",
                      export_name   = "stat_features.npz"):
    """
     stat_types:
        number of dimension
        -1: list of single value (stacking and stat on all axis),
        -2: list of single value (stacking and stat on axis 0->len-1),
        0: single value (stacking and stat on all axis),
        1: list, >1: n dimension (stat on axis on axis 0->len-1)
    """
    stat_fns = []
    for stat_name in stat_names:
        if stat_name == "mean":
            stat_fns.append(np.mean)
        elif stat_name == "std":
            stat_fns.append(np.std)
        elif stat_name == "max":
            stat_fns.append(np.max)
        elif stat_name == "min":
            stat_fns.append(np.min)

    stat_info = {feat_name: {stat_name: [] for stat_name in stat_names} for feat_name in stat_features}
    stat_data = {feat_name: {stat_name: [] for stat_name in stat_names} for feat_name in stat_features}
    print("Process Data")
    for data_name in data_names:
        n_data = data_cls.get_len(data_name)
        for index in tqdm(range(n_data), desc=f"{data_name}"):
            result = data_cls.read_data_index(index, data_name)
            for feat_name, stat_type in zip(stat_features,stat_types):
                feat_data = result[feat_name]
                if stat_data[feat_name].get("data") is None: stat_data[feat_name]["data"] = []
                if stat_type == 0:  # single value
                    ret_data = float(feat_data)
                    stat_data[feat_name]["data"].append(ret_data)
                elif stat_type == 1:  # array-1d
                    for stat_name, stat_fn in zip(stat_names, stat_fns):
                        ret_data = stat_fn(feat_data)
                        stat_info[feat_name][stat_name].append(ret_data)
                    # for
                elif stat_type >= 2:
                    for stat_name, stat_fn in zip(stat_names, stat_fns):
                        stat_axis = tuple(range(len(feat_data.shape) - 1))
                        ret_data = stat_fn(feat_data, axis=stat_axis)
                        stat_data[feat_name][stat_name].append(ret_data)
                    # for
                elif stat_type < 0:
                    ret_data = feat_data
                    stat_data[feat_name]["data"].append(ret_data)
            # for
            pass
        # for
    # for

    print("Process Stat")
    for feat_name, stat_type in zip(stat_features, stat_types):
        feat_data = np.array(stat_data[feat_name]["data"])
        for stat_name, stat_fn in zip(stat_names, stat_fns):
            stat_name_data = np.array(stat_data[feat_name][stat_name])
            if stat_type == 0:
                ret_data = stat_fn(feat_data)
            elif stat_type == 1:
                ret_data = np.mean(stat_name_data)
            elif stat_type>=2:
                stat_axis = tuple(range(len(stat_name_data.shape) - 1))
                ret_data = np.mean(stat_name_data, axis=stat_axis)
            elif stat_type == -1:
                ret_data = stat_fn(feat_data)
            elif stat_type == -2:
                stat_axis = tuple(range(len(feat_data.shape) - 1))
                ret_data = stat_fn(feat_data, axis = stat_axis)

            stat_info[feat_name][stat_name] = ret_data
        # for
    # for

    print("Save File")
    df_stat_info = []
    for feat_name in stat_info:
        row_info = {}
        row_info["feat_name"] = feat_name
        for stat_name in stat_info[feat_name]:
            row_info[stat_name] = np.array(stat_info[feat_name][stat_name]).tolist()
        df_stat_info.append(row_info)
    # for
    df_stat_info = pd.DataFrame(df_stat_info)

    if export_dir is not None and export_name is not None:
        if export_dir != "" and os.path.exists(export_dir) == False: os.makedirs(export_dir)
        export_path = os.path.join(export_dir, export_name)
        np.savez(export_path, stat_info)
        print(f"Saving stat features info: {export_path}!")
        xlsx_path = os.path.splitext(export_path)[0] + ".xlsx"
        df_stat_info.to_excel(xlsx_path)
        print(f"Saving stat features info: {xlsx_path}!")

    return stat_info, df_stat_info
# eda_stat_features