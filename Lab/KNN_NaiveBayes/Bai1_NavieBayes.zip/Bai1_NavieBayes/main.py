from NavieBayes import NaiveBayes
from sklearn import datasets
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score

iris = datasets.load_iris()
X = iris.data
y = iris.target
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
model = NaiveBayes()
model.fit(X_train, y_train)
predictions = model.predict(X_test)
print("Dự đoán:", predictions)
print("Thực tế:", y_test)
print(f"Accuracy: {accuracy_score(y_test, predictions) * 100:.2f}%")