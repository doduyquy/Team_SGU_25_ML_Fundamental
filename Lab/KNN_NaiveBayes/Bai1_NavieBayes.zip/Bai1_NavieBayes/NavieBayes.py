import numpy as np

class NaiveBayes:
    def __init__(self):
        self.classes = None
        self.mean = {}
        self.var = {}
        self.priors = {}

    def fit(self, X, y):
        """
        Huấn luyện mô hình.
        X: Ma trận đặc trưng (numpy array)
        y: Nhãn lớp (numpy array)
        """
        n_samples, n_features = X.shape
        self.classes = np.unique(y)

        for c in self.classes:
            # Lấy tất cả dữ liệu thuộc lớp c
            X_c = X[y == c]

            # 1. Tính toán Mean và Variance (Đại diện cho Gaussian - Lấy từ ý tưởng Code 2)
            self.mean[c] = np.mean(X_c, axis=0)
            self.var[c] = np.var(X_c, axis=0)

            # 2. Tính xác suất tiên nghiệm (Prior)
            self.priors[c] = X_c.shape[0] / n_samples

    def _calculate_log_likelihood(self, class_idx, x):
        mean = self.mean[class_idx]
        var = self.var[class_idx]
        
        # Thêm một hằng số rất nhỏ (epsilon) vào var để tránh chia cho 0
        epsilon = 1e-9
        
        numerator = -0.5 * ((x - mean) ** 2) / (var + epsilon)
        denominator = -0.5 * np.log(2 * np.pi * (var + epsilon))
        
        return numerator + denominator

    def predict(self, X):
        """
        Dự đoán phân lớp cho tập dữ liệu X
        """
        y_pred = []

        for x in X:
            posteriors = {}

            for c in self.classes:
                prior = np.log(self.priors[c])
                likelihood = np.sum(self._calculate_log_likelihood(c, x))
                posteriors[c] = prior + likelihood
            # Chọn lớp có xác suất cao nhất
            y_pred.append(max(posteriors, key=posteriors.get))

        return np.array(y_pred)


  