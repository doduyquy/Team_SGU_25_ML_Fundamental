import pandas as pd
import numpy as np
import random
from K_Nearest_Neighbors import K_Nearest_Neighbors as KNN

import os

def main():
    # DATA
    # Load dataset
    # Use absolute path relative to this script
    script_dir = os.path.dirname(os.path.abspath(__file__))
    dataset_path = os.path.join(script_dir, "dataset", "Iris.csv")
    df = pd.read_csv(dataset_path)

    # Drop Id column
    df.drop(['Id'], axis=1, inplace=True)

    data = df.values
    np.random.shuffle(data)

    X = data[:, :-1].astype(float)
    y = data[:, -1] 

    split_idx = int(len(data) * 0.8)

    X_train = X[:split_idx]
    y_train = y[:split_idx]
    X_test = X[split_idx:]
    y_test = y[split_idx:]

    print(f"Training set size: {len(X_train)}")
    print(f"Test set size: {len(X_test)}")

    knn = KNN(X_train, y_train, k=7)
    knn.test(X_test, y_test)

if __name__ == "__main__":
    main()