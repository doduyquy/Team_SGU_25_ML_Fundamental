import numpy as np
from collections import Counter

class K_Nearest_Neighbors:
    def __init__(self, X_train, y_train, k=3):
        """
        Initialize KNN with training data.
        
        Args:
            X_train (array-like): Training features
            y_train (array-like): Training labels
            k (int): Number of neighbors
        """
        self.X_train = np.array(X_train)
        self.y_train = np.array(y_train)
        self.k = k

    def predict(self, X_test):
        """
        Predict labels for test data.
        
        Args:
            X_test (array-like): Test features
            
        Returns:
            list: Predicted labels
        """
        X_test = np.array(X_test)
        predictions = []
        
        if X_test.ndim == 1:
            X_test = X_test.reshape(1, -1)
            
        for i in range(len(X_test)):

            distances = np.sqrt(np.sum((self.X_train - X_test[i])**2, axis=1))
            
            k_indices = np.argsort(distances)[:self.k]
            
            k_nearest_labels = [self.y_train[i] for i in k_indices]
            
            most_common = Counter(k_nearest_labels).most_common(1)
            predictions.append(most_common[0][0])
            
        return predictions

    def test(self, X_test, y_test):
        """
        Test the model and return accuracy.
        
        Args:
            X_test (array-like): Test features
            y_test (array-like): Test labels
            
        Returns:
            float: Accuracy
        """
        predictions = self.predict(X_test)
        correct = np.sum(np.array(predictions) == np.array(y_test))
        accuracy = correct / len(y_test)
        print(f"Accuracy: {accuracy:.4f}")
        return accuracy