import pandas as pd
import numpy as np
from K_Nearest_Neighbors import K_Nearest_Neighbors as KNN

def load_data(filepath):
    """
    Load Letter Recognition data.
    Format: letter, x-box, y-box, width, high, onpix, x-bar, y-bar, x2bar, y2bar, xybar, x2ybr, xy2br, x-ege, xegvy, y-ege, yegvx
    """
    df = pd.read_csv(filepath, header=None)
    
    y = df.iloc[:, 0].values
    X = df.iloc[:, 1:].values.astype(float)
    
    return X, y

def main():
    print("Loading Letter Recognition Dataset...")
    import os
    script_dir = os.path.dirname(os.path.abspath(__file__))
    dataset_path = os.path.join(script_dir, "dataset", "letter-recognition.data")
    
    try:
        X, y = load_data(dataset_path)
    except FileNotFoundError:
        print(f"Error: {dataset_path} not found. Please download it first.")
        return

    print(f"Dataset shape: {X.shape}")
    
    split_idx = 16000
    X_train = X[:split_idx]
    y_train = y[:split_idx]
    X_test = X[split_idx:]
    y_test = y[split_idx:]
    
    print(f"Training set size: {len(X_train)}")
    print(f"Test set size: {len(X_test)}")
 
    TEST_SUBSET_SIZE = 1000
    print(f"Testing on a subset of {TEST_SUBSET_SIZE} samples for speed...")
    
    knn = KNN(X_train, y_train, k=5) # k=5 is a common default
    knn.test(X_test[:TEST_SUBSET_SIZE], y_test[:TEST_SUBSET_SIZE])

if __name__ == "__main__":
    main()
